#!/usr/local/bin/perl

##############################################################################
# convert a yahoo business directory to a list of url -> home page query
##############################################################################

while (<STDIN>) {
    #interesting stuff is between <hr>'s
    $body=0 if /<hr>/i && $body; 
    $body=1 if /<hr>/i && !$body; 
    next unless $body;
    #start of anchor
    if (/\<a href="(http:\/\/.+)"\>(.*)/i) {
	($url,$name) = ($1,$2); 
	$anchored = 1;
    }
    #handle an anchor
    if ($anchored && /(.*)<\/a>/i) {
	$name .= $1;
	$anchored = 0;
	print "$url $name home page\n";
    } elsif ($anchored) {
	$name .= $line;
    } 	
}

