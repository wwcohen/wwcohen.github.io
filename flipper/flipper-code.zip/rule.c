/******************************************************************************
 rule.c - manipulate rule types
******************************************************************************/

#include <stdio.h>
#include "flipper.h"

/*****************************************************************************/

void fprint_rule(FILE *fp,rule_t *r)
{
    int n;

    fprint_lit(fp,r->head);
    fprintf(fp," :- ");
    fprint_query(fp,r->body);
    if (r->atleast && vmax(r->atleast)) {
      n = *vref(int,r->atleast,vmax(r->atleast)-1);
      if (n>0) {
	fprintf(fp," > %d",n);
      }
    }
    fprintf(fp," ; %d,%d.", r->nposx,r->nnegx);
}

rule_t *ld_rule(symbol_t *tok)
{
    rule_t *r;
    lit_t *lit;
    vec_t *body;
    int n;

    r = (rule_t *)new_refstate();
    body = new_vec(lit_t);

    lit = ld_lit(tok);
    refst_set_head(r,lit);
    tok = safe_lex(); 
    lex_verify(tok,Neck);

    tok = safe_lex();
    while (tok!=Stop && tok!=Semi && tok!=Gt && tok!=NULL) {
	lit = ld_lit(tok);
	ext_vec(lit_t,body,lit);
	tok = safe_lex();
	if (tok!=Stop && tok!=Semi && tok!=Gt) {
	    lex_verify(tok,Sep);	    
	    tok = safe_lex();
	}
    }
    refst_add_body(r,body);
    if (tok==Gt) {
	tok = safe_lex();
	if (tok->kind!=NUMBER) lex_error("bad number restriction");
	n = tok->numval;
	ext_vec(int,r->atleast,&n);
	tok = safe_lex();
    } else {
      n = 0;
      ext_vec(int,r->atleast,&n);
    }
    if (tok==Semi) {
	tok = safe_lex();
	if (tok->kind!=NUMBER) lex_error("bad positive count for rule");
	r->nposx = tok->numval;
	tok = safe_lex();
	lex_verify(tok,Sep);
	tok = safe_lex();
	if (tok->kind!=NUMBER) lex_error("bad negative count for rule");
	r->nnegx = tok->numval;
	tok = safe_lex();
    }
    lex_verify(tok,Stop);
    return r;
}

void free_rule(rule_t *r)
{
    free_refstate(r);
}

int rule_size(rule_t *r)
{
    return vmax(r->body)+1;
}


/* a null continuation that just succeeds */
static BOOL null_cont(char *dummy1, char *dummy2)
{
    return TRUE;
}

/* continuation that requires k successes 
 * this is initially called with count_addr holding the integer k
*/
static BOOL atleast_cont(char *count_addr, char *ex_addr)
{
    int *count;

    count = (int *) count_addr;
    return ((*count)-- <= 0); 
}


/* see if a rule covers an instance */ 
BOOL rule_covers(rule_t *r,vec_t *inst)
{
    int i;
    symbol_t *si,*ti;
    static int bound_vars[ARITY_BOUND];
    int n_bound;
    BOOL unifiable,covers;
    int cnt; 

    if (vmax(r->head->args)!=vmax(inst)) covers = FALSE;
    else {
	/* try and unify head with inst*/
	n_bound = 0;
	unifiable = TRUE;
	for (i=0; unifiable && i<vmax(r->head->args); i++) {
	    si = *vref(symbol_t *,r->head->args,i);
	    ti = *vref(symbol_t *,inst,i);
	    if (si->binding==NULL) {
		si->binding = ti;
		bound_vars[n_bound++] = i;
	    } else if (si->binding != ti) {
		unifiable = FALSE;
	    }
	}
	if (unifiable) {
	    if (r->atleast && vmax(r->atleast)) {
		cnt = *vref(int,r->atleast,vmax(r->atleast)-1);
		covers = prove(r->body,&atleast_cont,(char *)&cnt,NULL);
	    } else {
		covers = prove(r->body,&null_cont,NULL,NULL);
	    }
	}
	else covers = FALSE;

	/* unbind variables */
	for (i=0; i<n_bound; i++) {
	    si = *vref(symbol_t *,r->head->args,bound_vars[i]);
	    si->binding = NULL;
	}
    }
    return covers;
}

/* for optimizing repeated calls to rule_covers */
int index_rule(rule_t *r)
{
    int i,j;
    symbol_t *sj;
    int *unbound,n_unbound,n_headargs;
    symbol_t **headargs;
    BOOL body_well_formed;

    /* allocate pointers to bound/unbound variables in head */
    if (!r->head->bound) r->head->bound  =  new_vecn(int,vmax(r->head->args));
    else clear_vec(int,r->head->bound);
    if (!r->head->unbound) r->head->unbound  =  new_vecn(int,vmax(r->head->args));
    else clear_vec(int,r->head->unbound);

    headargs = vbase(symbol_t *,r->head->args);
    n_headargs = vmax(r->head->args);
    
    /* figure out locations of bound variables in head */
    for (j=0; j<n_headargs; j++) {
	sj = headargs[j];
	if (sj->binding!=NULL) {
	    ext_vec(int,r->head->bound,&j);
	} else {
	    ext_vec(int,r->head->unbound,&j);
	    /* simulate condition when called below */
	    sj->binding = Number[0];
	}
    }
    /* cache out some more properties of head */
    unbound = vbase(int,r->head->unbound);
    n_unbound = vmax(r->head->unbound);
    
    /* index the body */
    body_well_formed = index_query(r->body);

    /* unbind variables in head */
    for (i=0; i<n_unbound; i++) {
	headargs[unbound[i]]->binding = NULL;
    }
	
    return body_well_formed;
}

void unbind_indexed_rule(rule_t *r)
{
    int i,k;
    symbol_t *sk;

    /* unbind variables in head */
    for (i=0; i<vmax(r->head->unbound); i++) {
	k = *vref(int,r->head->unbound,i);
	sk = *vref(symbol_t *,r->head->args,k);
	sk->binding = NULL;
    }
    unbind_indexed_query(r->body);
}

BOOL indexed_rule_covers(rule_t *r,vec_t *inst)
{
    int i,j;
    int cnt;
    symbol_t *sj,*tj;
    static int *bound_vars,*unbound_vars;
    int n_bound,n_unbound;
    BOOL unifiable,covers;

    if (vmax(r->head->args)!=vmax(inst)) covers = FALSE;
    else {
	/* see and unify head with ground inst */
	n_bound = vmax(r->head->bound);
	bound_vars = vbase(int,r->head->bound);
	unifiable = TRUE;
	for (i=0; unifiable && i<n_bound; i++) {
	    j = bound_vars[i];
	    sj = *vref(symbol_t *,r->head->args,j);
	    tj = *vref(symbol_t *,inst,j);
	    if (sj->binding!=tj->binding) unifiable=FALSE;
	}
	if (unifiable) {
	    n_unbound = vmax(r->head->unbound);
	    unbound_vars = vbase(int,r->head->unbound);
	    for (i=0; i<n_unbound; i++) {
		j = unbound_vars[i];
		sj = *vref(symbol_t *,r->head->args,j);
		tj = *vref(symbol_t *,inst,j);
		sj->binding = tj;
	    }
	    if (r->atleast && vmax(r->atleast)) {
		cnt = *vref(int,r->atleast,vmax(r->atleast)-1);
		covers = prove_tail(r->body,0,&atleast_cont,(char *)&cnt,NULL);
	    } else {
		covers = prove_tail(r->body,0,&null_cont,NULL,NULL);
	    }
	    if (covers) unbind_indexed_query(r->body);
	    /* unbind variables in head */
	    for (i=0; i<n_unbound; i++) {
		j = unbound_vars[i];
		sj = *vref(symbol_t *,r->head->args,j);
		sj->binding = NULL;
	    }
	}
    }
    return covers;
}

/*****************************************************************************/

#ifdef TEST
char *Help_str[] = { "syntax: testrule [-v N] [-s data]", NULL };

main(argc,argv)
int argc;
char *argv[];
{
    rule_t *r; 
    symbol_t *tok;
    vec_t *data;
    example_t *exi;
    int i,cov;
    int o;

    while ((o=getopt(argc,argv,"v:sf:"))!=EOF) {
	switch (o) {
	  case 'v': set_trace_level(atoi(optarg)); break;
	  case 'f': data=ld_data(optarg); break;
	  case '?':
	  default:
	    give_help();
	    fatal("bad option -%c",o);
	}
    }

    if (data==NULL) warning("no data!");
    lex_open(NULL);
    while ((tok=lex())!=NULL) {
	r = ld_rule(tok);
	printf("rule: "); print_rule(r); printf("\n");
	for (i=0; data && i<vmax(data); i++) {
	    exi = vref(example_t,data,i);
	    cov = rule_covers(r,exi->inst);
	    print_example(exi); 
	    printf(" ==> %scovered.\n", cov?"":"un" );
	}
	printf("\nrule:\n");
	show_lit(r->head); printf(":-\n\t");
	show_query(r->body);
	printf(".\n");
    }
}

#endif
