/******************************************************************************
 predict-slog-main.c --- make predictions with a slog hypothesis
******************************************************************************/

#include <stdio.h>
#include <math.h>
#include "flipper.h"

/******************************************************************************/
char *Help_str[] = {
 "syntax: predict-slog [options] filestem",
 "",
 "options are:",
 " -v#      set trace level to #, which must be 0, 1, 2, or 3",
 " -e       echo hypothesis",
 " -s       read data from stdin",
 NULL
};

static symbol_t *Colon;

/*****************************************************************************/

typedef struct text_example_s {
    symbol_t *lab;
    vec_t *words;
} text_example_t;

static text_example_t *ld_text_example(symbol_t *);
BOOL text_classify(concept_t *,vec_t *,int *, int *);
BOOL text_prove(vec_t *,int,symbol_t *,vec_t *);
#define streq(x,y) (strcmp((x),(y))==0)

/****************************************************************************/

int main(int argc,char *argv[])
{
    text_example_t *exi;
    symbol_t *tok;
    concept_t *c;
    char *stem="foo";
    BOOL echo=FALSE;
    BOOL use_stdin=FALSE;
    int o,i,p,n;
    double tm;
    BOOL pred_class;

    set_trace_level(NONE);
    Colon = intern(":");

    while ((o=getopt(argc,argv,"v:es"))!=EOF) {
	switch (o) {
	  case 'v':
	    set_trace_level(atoi(optarg)); 
	    printf("option: trace level set to %d\n",trace_level());
	    break;
	  case 'e':
	    echo = TRUE;
	    break;
	  case 's':
	    use_stdin = TRUE;
	    break;
	  case '?':
	  default: 
	    give_help();
	    fatal("option not implemented");
	}
    }
    
    if (optind<argc) {
	stem = argv[optind++];
    } else {
	give_help();
	fatal("no file stem specified");
    }

    if (optind<argc) {
	warning("not all arguments were used: %s ...",argv[optind]);
    }

    c = ld_concept(add_ext(stem,".slog"));
    if (echo) {
	print_concept(c);
	exit(0);
    } else {
	if (use_stdin) lex_open(NULL);
	else lex_open(add_ext(stem,".test"));
    }
    while ((tok=lex())!=NULL) {
	exi = ld_text_example(tok);
	pred_class = text_classify(c,exi->words,&p,&n);
	printf("%c %d %d ","-+"[pred_class],p,n);
	if (streq(exi->lab->name,"pos")) printf("+\n");
	else printf("-\n");
    }
}

/* load an example */

static text_example_t *ld_text_example(symbol_t *tok)
{
    static text_example_t ex;
    
    if (ex.words==NULL) {
	ex.words = new_vecn(symbol_t *,10);
    }
    else clear_vec(symbol_t *,ex.words);

    /* save class */
    ex.lab = tok;
    tok = safe_lex(); lex_verify(tok,Colon); 

    tok=safe_lex();
    while (tok && tok!=Stop) {
	ext_vec(symbol_t *,ex.words,&tok);
	tok=safe_lex();
    }
    
    return &ex;
}

BOOL text_classify(concept_t *c,vec_t *words,int *p, int *n)
{
    int i;
    rule_t *ri;

    /* all rules in concept should be indexed */
    for (i=0; i<vmax(c->rules); i++) {
	ri = vref(rule_t,c->rules,i);
	if (text_rule_covers(ri,words)) {
	    (*p) = ri->nposx;
	    (*n) = ri->nnegx;
	    return TRUE;
	}
    }
    (*p) = c->nposx;
    (*n) = c->nnegx;
    return FALSE;
}

BOOL text_rule_covers(rule_t *r,vec_t *words)
{
    int i,j;
    lit_t *liti;
    symbol_t *sij;

    /* first initialize clause by unbinding all of the variables */
    for (i=0; i<vmax(r->body); i++)  {
	liti = vref(lit_t,r->body,i);
	/* start at 2 to skip functor/arity */
	for (j=2; j<vmax(liti->args); j++) {
	    sij = *vref(symbol_t *,liti->args,j);
	    sij->binding = NULL;
	}
    }
    sij = *vref(symbol_t *,r->head->args,2);
    return text_prove(r->body,0,sij,words);
}

/****************************************************************************/

static char *SpecialNames[] = {
    "succ",
    "near1",
    "near2",
    "near3",
    "after",
    NULL
};

static symbol_t *Special[100];

BOOL succ_f(double a,double b)  { return b==a+1; }
BOOL near1_f(double a,double b) { return b-a >= -1 && b-a <= 1; }
BOOL near2_f(double a,double b) { return b-a >= -2 && b-a <= 2; }
BOOL near3_f(double a,double b) { return b-a >= -3 && b-a <= 3; }
BOOL after_f(double a,double b) { return b>a; } 

typedef BOOL (*pintf)(double,double);

pintf Spec_f[] = {
    succ_f,
    near1_f,
    near2_f,
    near3_f,
    after_f,
    NULL
};

#define APPLY(fi,a,b)  ((*Spec_f[fi])((a),(b)))

BOOL text_prove(vec_t *goals,int next,symbol_t *docvar,vec_t *words)
{
    char nbuf[100];
    static BOOL initialized=FALSE;
    symbol_t *speci;
    static symbol_t *neq;    
    static int maxpos;
    static FILE *fp; 
    lit_t *lit;
    symbol_t *arg0,*arg1,*functor;
    int i,j;
    int fi,nwords;

    if (!initialized) {
	for (i=0; SpecialNames[i]!=NULL; i++) {
	    Special[i] = intern(SpecialNames[i]);
	}
    }

    /* have all goals been proved? */
    if (next>=vmax(goals)) return TRUE;

    /* if not, continue the proof in a continuation-passing sort of way */

    lit = vref(lit_t,goals,next);
    functor = *vref(symbol_t *,lit->args,1); 
    arg0 = *vref(symbol_t *,lit->args,2);
    arg1 = *vref(symbol_t *,lit->args,3);

    for (fi=0; Special[fi]; fi++) {
	if (Special[fi]==functor) break;
    }
    if (Special[fi]!=functor) fi = NULLINDEX;
    nwords = vmax(words);

    if (!lit->negated && fi!=NULLINDEX) {
	/* special relation */
	if (arg0->binding!=NULL && arg1->binding!=NULL) {
	    return (APPLY(fi,arg0->binding->numval,arg1->binding->numval)
		    && text_prove(goals,next+1,docvar,words));
	} else if (arg0->binding==NULL && arg1->binding!=NULL) {
	    for (i = 0; i<nwords; i++) {
		arg0->binding = Number[i];
		if (APPLY(fi,(double)i,arg1->binding->numval)
		    && text_prove(goals,next+1,docvar,words)) return TRUE;
	    }
	    return FALSE;
	} else if (arg0->binding!=NULL && arg1->binding==NULL) {
	    for (i=0; i<nwords; i++) {
		arg1->binding = Number[i];
		if (APPLY(fi,arg0->binding->numval,(double)i)
		    && text_prove(goals,next+1,docvar,words)) return TRUE;
	    }
	    return FALSE;
	} else {
	    fatal("two unbound arguments to binary relation!");
	}
    } else if (lit->negated && fi!=NULLINDEX) {
	/* negated special relation */
	if (arg0->binding!=NULL && arg1->binding!=NULL) {
	    return (!APPLY(fi,arg0->binding->numval,arg1->binding->numval)
		    && text_prove(goals,next+1,docvar,words));
	} else if (arg0->binding==NULL && arg1->binding!=NULL) {
	    for (i = 0; i<nwords; i++) {
		if (APPLY(fi,(double)i,arg1->binding->numval)) return;
	    }
	    return text_prove(goals,next+1,docvar,words);
	} else if (arg0->binding!=NULL && arg1->binding==NULL) {
	    for (i = 0; i<nwords; i++) {
		if (APPLY(fi,arg0->binding->numval,(double)i)) return FALSE;
	    }
	    return text_prove(goals,next+1,docvar,words);
	}
    } else if (!lit->negated) {
	/* positive word relation word(String,Pos) */
	if (arg0!=docvar) 
	  fatal("first argument of %s/2 not bound to string",functor->name);
    
	if (arg1->binding!=NULL) {
	    return (arg1->binding->numval>=0 && arg1->binding->numval<nwords
		    && streq((*vref(symbol_t *,words,arg1->binding->numval))->name,
			     functor->name+1)
		    && text_prove(goals,next+1,docvar,words));
	} else {
	    for (i=0; i<nwords; i++) {
		arg1->binding = Number[i];
		if (streq((*vref(symbol_t *,words,i))->name,functor->name+1))
		    return text_prove(goals,next+1,docvar,words);
	    }
	    return FALSE;
	}
    } else {
	/* negative word relation not(word(string,pos) */
	if (arg0!=docvar) 
	  fatal("first argument of %s/2 not bound to string",functor->name);

	if (arg1->binding!=NULL) {
	    return ((arg1->binding->numval>=nwords || arg1->binding->numval<0 ||
		     !streq((*vref(symbol_t *,words,arg1->binding->numval))->name,
			    functor->name+1))
		    && text_prove(goals,next+1,docvar,words)); 
	} else {
	    for (i=0; i<nwords; i++) {
		if (streq((*vref(symbol_t *,words,i))->name,functor->name+1))
		  return FALSE;
	    }
	    return text_prove(goals,next+1,docvar,words);
	}
    }
}

