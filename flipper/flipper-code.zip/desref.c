/******************************************************************************
 desref.c - apply refinement ops
******************************************************************************/

#include <stdio.h>
#include "flipper.h"

static BOOL store_refinement(char *, char *);

/*****************************************************************************/

/* top of refinement graph */
refstate_t *refinement_top()
{
    refstate_t *r;
    int zero=0;

    r = new_refstate();
    r->top = TRUE;
    r->level = 0;
    refst_add_tuples(r,Init_ref_tuples);
    return r;
}

/***************************************************************************/

static vec_t *Desgens=NULL;

void compute_designated_generalizations(refstate_t *refst)
{
    int i,len;
    refstate_t *gen;

    if (Desgens==NULL) Desgens=new_vec(refstate_t *);
    else {
	for (i=0; i<vmax(Desgens); i++) {
	    free_refstate(*vref(refstate_t *,Desgens,i));
	}
	clear_vec(refstate_t *,Desgens);
    }

    for (i=0; i<vmax(refst->body_len)-1; i++) {

	/* copy the existing state */
	gen = new_refstate();
	copy_refstate(gen,refst);

	/* truncate body to a possible appropriate length */
	len = *vref(int,refst->body_len,i);
	share_subvec(lit_t,gen->body,gen->body_space,0,len);

	/* truncate tuples */
	len = *vref(int,refst->tuple_len,i);
	share_subvec(vec_t *,gen->tuples,gen->tuple_space,0,len);

	/* and truncate the "choices", atleast, and length vectors  */
	shorten_vecn(int,gen->body_len,vmax(gen->body_len)-i-1);
	shorten_vecn(int,gen->tuple_len,vmax(gen->tuple_len)-i-1);
	shorten_vecn(int,gen->choices,vmax(gen->choices)-i-1);
	shorten_vecn(int,gen->atleast,vmax(gen->atleast)-i-1);

	/* save the generalization */
	ext_vec(refstate_t *,Desgens,&gen);
    }
}

/* access the generalizations */

int n_designated_generalizations()
{
    return vmax(Desgens);
}

refstate_t *generalization(int i)
{
    return *vref(refstate_t *,Desgens,i);
}


/***************************************************************************/

static vec_t *Desrefs=NULL;

/* compute all refinements of a sentential form */
void compute_designated_refinements(refstate_t *refst)
{
    int i,tmp;
    refop_t *refi;
    refstate_t *refsti;

    if (Desrefs==NULL) Desrefs=new_vec(refstate_t *);
    else {
	for (i=0; i<vmax(Desrefs); i++) {
	    free_refstate(*vref(refstate_t *,Desrefs,i));
	}
	clear_vec(refstate_t *,Desrefs);
    }

    /* prove the where part of each refinement using store_refinement
       as the continuation---this means that for every proof a new
       refinement will be stored 
    */   
    for (i=0; i<vmax(Ref_ops); i++) {
	refi = vref(refop_t,Ref_ops,i);
	if (refst->top && refi->head) {
	    slow_prove(refi->where,refst->tuples,
		       store_refinement,(char *)refst,(char *)refi);
	} else if (!refst->top && !refi->head) {
	    slow_prove(refi->where,refst->tuples,
		       store_refinement,(char *)refst,(char *)refi);
	}
    }

    /* finally store number of possible refinements */
    tmp = vmax(Desrefs);
    for (i=0; i<vmax(Desrefs); i++) {
	refsti = *vref(refstate_t *,Desrefs,i);
	ext_vec(int,refsti->choices,&tmp);
    }
}


/* access the refinements */

int n_designated_refinements()
{
    return vmax(Desrefs);
}

refstate_t *refinement(int i)
{
    return *vref(refstate_t *,Desrefs,i);
}


/****************************************************************************/

/* workhorse routine for compute_designated_refinements
 * ---called as a continuation by slow_prove
 */ 
static BOOL store_refinement(char *prev_st_addr, char *ref_addr)
{
    int i,j,tmp;
    lit_t *liti;
    symbol_t *sij;
    char buf[BUFSIZ];
    refstate_t *new_refst;
    refstate_t *prev_refst;
    refop_t *ref;
    static vec_t *boundvars=NULL;

    if (boundvars==NULL) boundvars = new_vec(symbol_t *);
    else clear_vec(symbol_t *,boundvars);

    prev_refst = (refstate_t *) prev_st_addr;
    ref = (refop_t *) ref_addr;

    /* apply the refinement to prev_refst to get new_refst. 
       - copy ref->head 
       - bind unbound variables in ref->body to gensymed variables
       - append bound version of ref->body to prev->head
       - append bound version of asserts to tuples
       - record length of body, tuples
    */   

    /* allocate a new refstate, and leave a pointer to it in Desref */
    new_refst = new_refstate();
    ext_vec(refstate_t *,Desrefs,&new_refst);

    new_refst->level = prev_refst->level+1;

    if (ref->head) refst_set_head(new_refst, ref->head);
    else refst_set_head(new_refst, prev_refst->head);

    /* bind vars in ref body to gensyms */
    for (i=0; i<vmax(ref->body); i++) {
	liti = vref(lit_t,ref->body,i);
	for (j=0; j<vmax(liti->args); j++) {
	    sij = *vref(symbol_t *,liti->args,j);
	    if (sij->binding==NULL) {
		sprintf(buf,"%s%d",sij->name,prev_refst->level);
		sij->binding = make_variable(intern(buf));
		ext_vec(symbol_t *,boundvars,&sij);
	    }
	}
    }

    /* append instantiated body of ref to body from prev_refst */
    refst_add_body(new_refst,prev_refst->body);
    refst_add_body(new_refst,ref->body);

    /* record what variable needs to be "fixed" */
    if (ref->fixing) {
	new_refst->fixing = ref->fixing->binding;
	if (new_refst->fixing==NULL) 
	  error("variable to 'fix' does not appear in refinement body");
    }

    /* append instantiated tuples of ref to tuples from prev_refst */
    refst_add_tuples(new_refst,prev_refst->tuples);
    refst_add_tuples(new_refst,ref->assert);

    /* append new length to length vectors */
    copy_vec(int,new_refst->body_len,prev_refst->body_len);
    tmp = vmax(new_refst->body);
    ext_vec(int,new_refst->body_len,&tmp);

    copy_vec(int,new_refst->tuple_len,prev_refst->tuple_len);
    tmp = vmax(new_refst->tuples);
    ext_vec(int,new_refst->tuple_len,&tmp);

    /* copy old list of at-least thresholds, and extend with a zero */
    copy_vec(int,new_refst->atleast,prev_refst->atleast);
    tmp = 0;
    ext_vec(int,new_refst->atleast,&tmp);

    /* copy choices */
    copy_vec(int,new_refst->choices,prev_refst->choices);

    /* unbind variables that were bound in this routine */
    for (i=0; i<vmax(boundvars); i++) {
	sij = *vref(symbol_t *,boundvars,i);
	sij->binding = NULL;
    }

    /* force backtracking */
    return FALSE;
}

