/******************************************************************************
 concept.c - manipulate concept type
******************************************************************************/

#include <stdio.h>
#include "flipper.h"

/*****************************************************************************/

void fprint_concept(FILE *fp,concept_t *c)
{
    int i;

    for (i=0; i<vmax(c->rules); i++) {
	fprint_rule(fp,vref(rule_t,c->rules,i));
	fprintf(fp,"\n");
    }
    fprintf(fp,"; %d,%d.\n",c->nposx,c->nnegx);
}

/* print a computer-readable version of the concept */
void fshow_concept(FILE *fp,concept_t *c)
{
    fprint_concept(fp,c);
}

/* read a computer-readable version of the concept */
concept_t *ld_concept(char *filename)
{
    concept_t *c;
    rule_t *r;
    symbol_t *tok;

    if (!lex_open(filename)) {
	return NULL;
    } else {
	c = newmem(1,concept_t);
	c->rules = new_vec(rule_t);
	tok = lex();
	while (tok!=NULL && tok!=Semi) {
	    r = ld_rule(tok);
	    index_rule(r);
	    ext_vec(rule_t,c->rules,r);
	    tok = lex();
	}
	if (tok==Semi) {
	    tok = safe_lex();
	    if (tok->kind!=NUMBER) lex_error("bad positive count for concept");
	    c->nposx = tok->numval;
	    tok = safe_lex();
	    lex_verify(tok,Sep);
	    tok = safe_lex();
	    if (tok->kind!=NUMBER) lex_error("bad negative count for concept");
	    c->nnegx = tok->numval;
	    tok = safe_lex();
	    lex_verify(tok,Stop);
	}
	lex_close();
	return c;
    }
}


int concept_size(concept_t *c)
{
    int i,sz;

    sz = 0;
    for (i=0; i<vmax(c->rules); i++) {
	sz += rule_size(vref(rule_t,c->rules,i));
    }
    return sz;
}

void free_concept(concept_t *c)
{
    int i;

    for (i=0; i<vmax(c->rules); i++) {
	free_rule(vref(rule_t,c->rules,i));
    }
    free_vec(rule_t,c->rules);
    c->rules = NULL;
}

BOOL classify(concept_t *c,vec_t *inst)
{
    int d1,d2;
    return classify_counts(c,inst,&d1,&d2);
}

BOOL classify_counts(concept_t *c,vec_t *inst,int *p, int *n)
{
    int i;
    rule_t *ri;

    /* all rules in concept should be indexed */
    for (i=0; i<vmax(c->rules); i++) {
	ri = vref(rule_t,c->rules,i);
	if (indexed_rule_covers(ri,inst)) {
	    (*p) = ri->nposx;
	    (*n) = ri->nnegx;
	    return TRUE;
	}
    }
    (*p) = c->nposx;
    (*n) = c->nnegx;
    return FALSE;
}

/* update counts & weights for all the rules, and index rules */
void count_concept(concept_t *hyp, vec_t *data)
/* hyp is side-effected */
{
    int i,j,k;
    int tot_pos,tot_neg;
    rule_t *rulej;
    example_t *exi;
    BOOL exi_covered;
    int most_uncov;
    static int *cl_counts;
    
    /* reset counts and index rules */
    for (j=0; j<vmax(hyp->rules); j++) {
	rulej = vref(rule_t,hyp->rules,j);
	index_rule(rulej);
	rulej->nposx = rulej->nnegx = 0;
    }
    hyp->nposx = hyp->nnegx = 0;

    /* now look at each example and update counts */
    for (i=0; i<vmax(data); i++) {
	exi = vref(example_t,data,i);
	exi_covered = FALSE;
	for (j=0; j<vmax(hyp->rules); j++) {
	    rulej = vref(rule_t,hyp->rules,j);
	    if (indexed_rule_covers(rulej,exi->inst)) {
		exi_covered = TRUE;
		if (exi->lab==TRUE) rulej->nposx++;
		else rulej->nnegx++;
		break; /* skip later rules */
	    }
	} /* for rule j*/
	/* count uncovered examples */
	if (!exi_covered) {
	    if (exi->lab==FALSE) hyp->nposx++;
	    else hyp->nnegx++;
	}
    } /* for example i */
}
