#include <stdio.h>
#include <math.h>
#include "flipper.h"

extern char *Help_str[];

char *add_ext(str,ext)
char *str, *ext;
{
    char *ret;

    ret = newmem(strlen(str)+strlen(ext)+1,char);
    sprintf(ret,"%s%s",str,ext);
    return ret;
}

void give_help()
{
    static BOOL gave_help=FALSE;
    int i;

    if (!gave_help) {
	for (i=0; Help_str[i]; i++) printf("%s\n",Help_str[i]);
	gave_help = TRUE;
    }
}

