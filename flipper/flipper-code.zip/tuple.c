/******************************************************************************
 tuple.c - read in sets of tuples
******************************************************************************/

#include <stdio.h>
#include "slog.h"

vec_t *All_tuples; /* vector of vectors */
int Max_arity;

vec_t ***Index;   /* Index[i][j] is a vector
		     containing in order the indices 
		     in All_tuples that contain the constant
		     with index i in column j 
		  */   
int Max_indexed_const;
int Max_indexed_col;

/*****************************************************************************/

BOOL ld_tuples(char *file)
{
    vec_t *tup;
    symbol_t *tok;

    if (!lex_open(file)) {
	error("can't open tuple file %s");
	return FALSE;
    } else {
	while ((tok=lex())!=NULL) {
	    if (tok==Stop && vmax(All_tuples)>0) {
		/* Stop char is leftover from last time */
		tok = lex(); 
		if (tok==NULL) return TRUE;
	    }
	    tup = ld_tuple(tok);
	    add_tuple(tup);
	}
	return TRUE;
    }
}

void add_tuple(vec_t *tup)
{
    if (All_tuples==NULL) {
	All_tuples = new_vec(vec_t *);
	Max_arity = 0;
    }

    ext_vec(vec_t *,All_tuples,&tup);
    if (vmax(tup)>Max_arity) {
	Max_arity = vmax(tup);
	if (Max_arity>ARITY_BOUND) 
	  fatal("tuple arity too large---limit is %d",ARITY_BOUND);
    }
}

vec_t *ld_tuple(symbol_t *tok)
{
    vec_t *tup;

    /* allocate space */
    tup = new_vec(symbol_t *);

    /* first element of tuple will indicate length */
    ext_vec(symbol_t *,tup,&Number[0]); 
    
    ext_vec(symbol_t *,tup,&tok); /* functor */
    tok = safe_lex(); 
    if (tok==Open_par) {
	tok=safe_lex(); /* first argument */
	while (tok!=Close_par) {
	    ext_vec(symbol_t *,tup,&tok); /* argument */	    
	    tok = safe_lex(); 
	    if (tok==Sep) tok=safe_lex();
	    else if (tok!=Close_par) lex_error("expected ',' or ')'");
	}
    } else {
	unlex();
    }

    /* store the actual length */
    vset(symbol_t *,tup,0,&Number[vmax(tup)-1]);
    return tup;
}

/*****************************************************************************/

void index_tuples()
{
    int i,j,k;
    vec_t *tupk;
    symbol_t *akj;

    trace(LONG) { 
	printf("// indexing: %d tuples, %d constants, arity %d\n",
	       vmax(All_tuples), Num_const, Max_arity);
    }

    /* free old index if necessary */
    if (Index!=NULL) {
	for (i=0; i<Num_const; i++) {
	    for (j=0; j<Max_arity; j++) {
		free_vec(symbol_t *,Index[i][j]);
		Index[i][j] = NULL;
	    }
	    freemem(Index[i]);
	}
    }

    Index = newmem(Num_const,vec_t **);
    for (i=0; i<Num_const; i++) {
	Index[i] = newmem(Max_arity,vec_t *);
	for (j=0; j<Max_arity; j++) {
	    Index[i][j] = new_vec(int); 
	}
    }
    for (k=0; k<vmax(All_tuples); k++) {
	tupk = *vref(vec_t *,All_tuples, k);
	for (j=0; j<vmax(tupk); j++) {
	    akj = *vref(symbol_t *,tupk,j);
	    ext_vec(int,Index[akj->index][j],&k);
	}
    }
    Max_indexed_const = Num_const;
    Max_indexed_col = Max_arity;
}

/*****************************************************************************/

void print_tuple(vec_t *tup,BOOL subst)
{
    fprint_tuple(stdout,tup,subst);
}

void fprint_tuple(FILE *fp,vec_t *tup,BOOL subst)
{
    int i;
    symbol_t *s;

    if (tup==NULL) fprintf(fp,"(null tuple)");
    else if (vmax(tup)<=1) fprintf(fp,"<>");
    else { 
	/* proper tuple, stored as <arity v1 ... vk> */
	s = *vref(symbol_t *,tup,1);
	if (subst && s->binding) fprint_symbol(fp,s->binding);
	else fprint_symbol(fp,s);
	if (vmax(tup)>2) {
	    fprintf(fp,"(");
	    for (i=2; i<vmax(tup); i++) {
		s = *vref(symbol_t *,tup,i);
		if (subst && s->binding) fprint_symbol(fp,s->binding);
		else fprint_symbol(fp,s);
		if (i!=vmax(tup)-1) fprintf(fp,",");
	    }
	    fprintf(fp,")");
	}
    }
}

void show_tuples()
{
    vec_t *v;
    int i,j,k;

    for (i=0; i<vmax(All_tuples); i++) {
	printf("%4d: ",i);
	fprint_tuple(stdout,*vref(vec_t *,All_tuples,i),FALSE);
	printf("\n");
    }
    printf("\n\n");
    for (i=0; i<Num_const; i++) {
	for (j=0; j<Max_arity; j++) {
	    v = Index[i][j];
	    if (vmax(v)>0) {
		printf("Index[%d][%d]:",i,j);
		for (k=0; k<vmax(v); k++) {
		    printf(" %d",*vref(int,v,k));
		}
		printf("\n");
	    }
	}
    }
}


#ifdef TEST
/*****************************************************************************/
/* main: test driver
*/

main(argc,argv)
int argc;
char *argv[];
{
    int i,j,k,ret;
    vec_t *v;

    if (argc<=1) ret=ld_tuples(NULL);
    else ret=ld_tuples(argv[1]);
 
    if (ret) {
	index_tuples();
	for (i=0; i<vmax(All_tuples); i++) {
	    printf("%4d: ",i);
	    fprint_tuple(stdout,*vref(vec_t *,All_tuples,i),FALSE);
	    printf("\n");
	}
	printf("\n\n");
	for (i=0; i<Num_const; i++) {
	    for (j=0; j<Max_arity; j++) {
		v = Index[i][j];
		if (vmax(v)>0) {
		    printf("Index[%d][%d]:",i,j);
		    for (k=0; k<vmax(v); k++) {
			printf(" %d",*vref(int,v,k));
		    }
		    printf("\n");
		}
	    }
	}
    }
}
#endif
