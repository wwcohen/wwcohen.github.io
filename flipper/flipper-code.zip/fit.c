/******************************************************************************
 fit.c - find a model that fits the data

******************************************************************************/

#include <stdio.h>
#include "flipper.h"

BOOL Simplify=TRUE;
double FP_cost=1.0;
double FN_cost=1.0;
double Max_decompression=32.0;
int Optimizations=1;

/* locally used functions */
static void fit1(vec_t *,vec_t *);
static void refine(refstate_t *,vec_t *);
static BOOL stop_refining(refstate_t *,int,int);
static BOOL reject_refinement(refstate_t *,int,int,int,int);
static void simplify(refstate_t *,vec_t *,int,vec_t *);
static BOOL reject_rule(refstate_t *,int,int,vec_t *,vec_t *,double *,double *);
static double rule_value(refstate_t *,vec_t *,int,vec_t *);
static void count_distribution(vec_t *,int *,int *);
static double relative_errors(refstate_t *,vec_t *);
static void remove_covered_examples(refstate_t *,vec_t *,int *,int *);

/*****************************************************************************/

/* iterate fit1 to get good hypothesis */
vec_t *fit(vec_t *data)
{
    int i,trial_num;
    vec_t *hyp;

    /* hyp starts as empty ruleset */ 
    hyp = new_vec(rule_t);

    /* my algorithm */
    if (!Simplify) {
	fit1(data,hyp);
    } else {
	fit1(data,hyp);
	trace(SUMM) {
	    printf("// current ruleset:\n");
	    for (i=0; i<vmax(hyp); i++) {
		printf("//    ");
		print_rule(vref(rule_t,hyp,i));
		printf("\n");
	    }
	    fflush(stdout);
	}
	reduce_dlen(hyp,data);
	/* iterate fit1  */
	for (trial_num=0; trial_num<Optimizations; trial_num++) {
	    trace (SUMM) {
		printf("// optimizing rules---pass %d of %d\n",
		       trial_num+1,Optimizations);
		fflush(stdout);
	    }
	    fit1(data,hyp);
	    reduce_dlen(hyp,data);

	    trace(SUMM) {
		printf("// current ruleset:\n");
		for (i=0; i<vmax(hyp); i++) {
		    printf("//    ");
		    print_rule(vref(rule_t,hyp,i));
		    printf("\n");
		}
		fflush(stdout);
	    }
	}
    }
    return hyp;
}

/* use a greedy strategy to find rules to cover the examples of class cl */
static void fit1(vec_t *data,vec_t *rules)
{
    int all_p,all_n,rule_p,rule_n;
    rule_t *curr_rule,tmp_rule;
    vec_t data1,grow_data,prune_data;
    refstate_t *new_state,*old_state,*rev_state,*best_state;
    BOOL last_rule_accepted,revising_rule;
    int rule_num;
    double new_val,old_val,rev_val,pr_val;
    double comp,best_comp;
    int i,tmp_p,tmp_n;
    char *operation;
    int n_deleted;

    comp = best_comp = 0.0;

    share_vec(example_t,&data1,data);
    count_distribution(&data1,&all_p,&all_n);

    rule_num = 0;
    n_deleted = 0;
    last_rule_accepted = TRUE;

    /* main loop: learn a set of rules */

    while (all_p>0 && last_rule_accepted) {

	/* determine the starting points for growing rules */
	new_state = refinement_top();

	if (rule_num >= vmax(rules)) {
	    revising_rule = FALSE;
	} else {
	    revising_rule = TRUE;
	    old_state = vref(refstate_t,rules,rule_num);
	    rev_state = new_refstate();
	    copy_refstate(rev_state,old_state);
	}

	/* don't bother revising a rule that's subsumed by an earlier one */
	if (revising_rule) {
	    count_examples(old_state,&data1,&rule_p,&rule_n);
	    old_state->nposx = rule_p;
	    old_state->nnegx = rule_n;
	    trace(LONG) {
		printf("// old rule %d: ",rule_num+1);
		print_rule(old_state); printf("\n");
		fflush(stdout);
	    }
	    if (rule_p==0 && rule_n==0) {
		trace (SUMM) {
		    printf("// r%d skipped [null coverage] ",rule_num+1);
		    print_rule(old_state); printf("\n");
		    fflush(stdout);
		}
		free_refstate(new_state); 
		n_deleted++;
		rule_num++;
		continue;
	    }
	}

	/* grow a new rule, and possibly a revised version of old rule */
	if (!Simplify) {
	    refine(new_state,&data1);	
	} else {
	    stratified_partition(&data1,3,&grow_data,&prune_data);
	    trace(LONG) printf("// finding new rule %d\n",rule_num+1);
	    refine(new_state,&grow_data);

	    /* remove examples covered by later rules from pruning set 
	       since the current rule can't change their classification */
	    for (i=rule_num+1; i<vmax(rules); i++) {
		remove_covered_examples(vref(rule_t,rules,i),&prune_data,&tmp_p,&tmp_n);
	    }
	    simplify(new_state,rules,rule_num,&prune_data);
	    if (revising_rule) {
		trace(LONG) printf("// revising rule %d\n",rule_num+1);
		refine(rev_state,&grow_data);
		simplify(rev_state,rules,rule_num,&prune_data);
	    }
	}
	
	/* decide which rule is best */
	if (!revising_rule) {
	    count_examples(new_state,&data1,&rule_p,&rule_n);
	    if (reject_rule(new_state,rule_p,rule_n,rules,&data1,&comp,&best_comp)) {
		last_rule_accepted = FALSE;
		free_refstate(new_state); 
	    } else {
		new_state->nposx = rule_p;
		new_state->nnegx = rule_n;
		/* index_rule((rule_t *)new_state);  */
		ext_vec(refstate_t,rules,new_state);
		remove_covered_examples(new_state,&data1,&all_p,&all_n);
		trace(SUMM) {
		    pr_val = 
		      Simplify?
			rule_value(new_state,rules,rule_num,&prune_data):
			rule_value(new_state,rules,rule_num,&data1);
		    printf("// r%d added [m=%d,v=%.3f,c=%g] ",
			   rule_num+1,vmax(&data1),pr_val,comp);
		    print_rule(new_state); printf("\n");
		    fflush(stdout);
		}
		rule_num++;
	    }
	} else /* revising rule */ {

	    new_val = relative_compression(new_state,rules,rule_num,&data1);
	    rev_val = relative_compression(rev_state,rules,rule_num,&data1);
	    old_val = relative_compression(old_state,rules,rule_num,&data1);

	    trace(LONG) {
		printf("// value: old=%.3f rev=%.3f new=%.3f\n", 
		       old_val,rev_val,new_val);
		fflush(stdout);
	    }
	    if (old_val >= new_val && old_val >= rev_val) {
		count_examples(old_state,&data1,&rule_p,&rule_n);
		old_state->nposx = rule_p;
		old_state->nnegx = rule_n;
		/* index_rule((rule_t *) old_state); */
		vset(refstate_t,rules,rule_num,old_state);
		free_refstate(new_state); 
		free_refstate(rev_state); 
		best_state=old_state; 
		trace(SUMM) { operation="retained"; pr_val = old_val; }
	    } else if (rev_val>=new_val) {
		count_examples(rev_state,&data1,&rule_p,&rule_n);
		rev_state->nposx = rule_p;
		rev_state->nnegx = rule_n;
		/* index_rule((rule_t *) rev_state); */
		vset(refstate_t,rules,rule_num,rev_state);
		free_refstate(new_state); 
		/* free_refstate(old_state); */
		best_state=rev_state; 
		trace(SUMM) { operation="revised"; pr_val = rev_val; }
	    } else /* new_val is best */ {
		count_examples(new_state,&data1,&rule_p,&rule_n);
		new_state->nposx = rule_p;
		new_state->nnegx = rule_n;
		/* index_rule((rule_t *) new_state); */
		vset(refstate_t,rules,rule_num,new_state);
		free_refstate(rev_state); 
		/* free_refstate(old_state); */
		best_state=new_state; 		
		trace(SUMM) { operation="replaced"; pr_val = new_val; }
	    }
	    remove_covered_examples(best_state,&data1,&all_p,&all_n);
	    /* I shouldn't need this */
	    count_distribution(&data1,&all_p,&all_n);
	    trace(SUMM) {
		printf("// r%d %s [m=%d,c=%.3f] ",
		       rule_num+1,operation,vmax(&data1),pr_val);
		print_rule(best_state); printf("\n");
		fflush(stdout);
	    }
	    rule_num++;
	}
    } /* while allp>0 and last_rule_accepted */
}

/* use a greedy strategy to refine a rule */
static void refine(refstate_t *ref,vec_t *data)
/* ref is side-effected */
{
    int p,n,p1,n1;
    vec_t data1;
    int i, best_i;
    example_t *exi;
    BOOL last_refinement_rejected;
    double best_val, vali, prev_info;

    trace(LONG) {
	printf("// refining:  "); 
	print_refstate(ref); 
	printf("\n");
	fflush(stdout);
    }

    share_vec(example_t,&data1,data);

    count_distribution(&data1,&p,&n);
    prev_info = information(p,n);
    last_refinement_rejected = FALSE;
    while (!stop_refining(ref,p,n) && !last_refinement_rejected) {
	
	/* find the best refinement */
	compute_designated_refinements(ref);
	if (n_designated_refinements()<= 0) {
	    last_refinement_rejected = TRUE;
	} else {

	    /* pick the best refinement */
	    best_val = -MAXREAL; 
	    best_i = -1;
	    for (i=0; i<n_designated_refinements(); i++) {
		vali = value(refinement(i),&data1,ref,n,prev_info);
		if (vali > best_val) {
		    best_val = vali; best_i = i; 
		}
	    }
	    
	    /* decide if it's worth keeping */
	    count_examples(refinement(best_i),&data1,&p1,&n1);
	    if (reject_refinement(ref,p,n,p1,n1)) {
		last_refinement_rejected = TRUE;
		trace(LONG) {
		    printf("// stopped refining (%d/%d) ",p1,n1);
		    print_refstate(refinement(best_i));
		    printf("\n");
		    fflush(stdout);
		}
	    } else {
		
		copy_refstate(ref,refinement(best_i));
		p = p1; n = n1; prev_info = information(p,n);
		
		/* update the data by removing uncovered examples */
		if (!Number_restrictions) {
		    index_rule((rule_t *)ref);
		    i=0;
		    while (i<vmax(&data1)) {
			exi = vref(example_t,&data1,i);
			if (!indexed_rule_covers((rule_t *)ref,exi->inst)) 
			  swap_out_example(&data1,i);
			else i++;
		    } 
		}
		trace(LONG) {
		    printf("// refined to (%d/%d): ",p,n); 
		    print_refstate((rule_t *) ref); 
		    printf("\n");
		    fflush(stdout);
		}
	    } /* else !reject_refinement(..) */
	} /* else some refinements */
    } /* while !stop_refinements */ 
}

/* use greedy strategy to simplify a rule */
static void simplify(refstate_t *ref,vec_t *rules,int rule_num,vec_t *prune_data)
/* ref side-effected here */
{
    int i, j, best_j, p, n;
    double val, best_val;

    best_val = rule_value(ref,rules,rule_num,prune_data);
    trace(LONG) {
	count_examples(ref,prune_data,&p,&n);
	printf("// simplifying with %d examples\n",vmax(prune_data)); 
	printf("// initial rule [%d/%d val=%.3f]: ",p,n,best_val);
	print_refstate(ref); 
	printf("\n");
	fflush(stdout);
    }

    compute_designated_generalizations(ref);
    while (n_designated_generalizations() > 0) {

	/* look for a generalization better than best_val */
	best_j = -1; 
	for (j=0; j<n_designated_generalizations(); j++) {
	    val = rule_value(generalization(j),rules,rule_num,prune_data);
	    trace(LONG) {
		count_examples(generalization(j),prune_data,&p,&n);
		printf("// gen %d [%d/%d val=%.3f]: ",j,p,n,val);
		print_refstate(generalization(j));
		printf("\n");
	    }
	    if (val >= best_val) {
		best_val = val;
		best_j = j;
	    }		  
	} /*for generalization j */
	if (best_j == -1) {
	    /* nothing better found */
	    break;
	} else {
	    /* something better found */
	    copy_refstate(ref,generalization(best_j));
	    trace(LONG) {
		count_examples(ref,prune_data,&p,&n);
		printf("// simplified to [%d/%d val=%.3f] ",p,n,best_val); 
		print_refstate(ref); 
		printf("\n");
		fflush(stdout);
	    }
	    compute_designated_generalizations(ref);
	} 
    } /* while n_generalizations>0 */
    trace(LONG) {
	val = rule_value(ref,rules,rule_num,prune_data);
	count_examples(ref,prune_data,&p,&n);
	printf("// final rule [%d/%d val=%.3f]: ",p,n,val); 
	print_refstate(ref); 
	printf("\n");
	fflush(stdout);
    }
}

/* decide when to stop refining and when to reject a refinement */
static BOOL stop_refining(refstate_t *ref,int p,int n)
{
    return (n==0);
}

static BOOL reject_refinement(refstate_t *r,int pi,int ni,int pj,int nj)
{
    /* pi,ni are current stats: pj,nj are stats for refinement */ 

    if (r->top) return FALSE;
    if (pj==0) return TRUE;
    if (pj==pi && ni==nj) return TRUE;
    /* else */ 
    return FALSE;
}

static BOOL reject_rule(refstate_t *r,int p,int n,vec_t *rules,
			vec_t *data,double *pcomp,double *pbest_comp)
{
    char reason[100];
    double decomp; 
    BOOL ret;
    int allp,alln;

    /* enforce a description-length based cut-off */
    (*pcomp) += relative_compression(r,rules,vmax(rules),data);
    if ((*pcomp) > (*pbest_comp)) {
	(*pbest_comp) = (*pcomp);
    } 
    if ((*pcomp) < (*pbest_comp) - Max_decompression) {
	ret = TRUE;
	sprintf(reason,"description length too large");
    } else if (p==0) {
	ret = TRUE;
	sprintf(reason,"too few positive examples");
    } else if (n*FP_cost/(p*FN_cost + n*FP_cost) >= 0.5) {
	ret = TRUE;
	sprintf(reason,"error rate too large");
    } else {
	ret = FALSE;
	sprintf(reason,"");
    }
    trace (LONG) {
	printf("// final rule compression is %g (best %g)\n",
	       (*pcomp),(*pbest_comp));
	fflush(stdout);
    }
    trace (SUMM) {
	if (ret) {
	    printf("// rejected [%s] ",reason);
	    print_refstate(r);
	    printf("\n");
	}
	fflush(stdout);
    }
    return ret;
}

static double rule_value(refstate_t *r,vec_t *rules,int rule_num,vec_t *data)
{

    int i,P,N,p,n;
    double num,denom;
    double ret,errs;

    if (rule_num >= vmax(rules)) {     
	/* if adding a rule, use modified Furncrantz metric */
	count_examples(r,data,&p,&n);
	num = (p+1)*FN_cost - (n+1)*FP_cost;
	denom = p*FN_cost + (n+1)*FP_cost + 1;
	ret =  num/denom;
    } else { 
	/* if revising, use accuracy of theory resulting
	 * from replacing rules[rule_num] with form */
	errs = relative_errors(r,data);
	ret = 1.0 - errs/vmax(data);
    }
    return ret;
}

/* count members of a class */
static void count_distribution(vec_t *data,int *p,int *n)
{
    example_t *exi;
    int i;

    (*p) = (*n) = 0;
    for (i=0; i<vmax(data); i++) {
	exi = vref(example_t,data,i);
	if (exi->lab) (*p)++;
	else (*n)++;
    }
}

/* number of errors made on data if with ruleset
 * consisting of first, a rule with antec form and conseq cl;
 * and second, the rules in rules starting at position rstart
 */
static double relative_errors(refstate_t *r,vec_t *data)

{
    example_t *exi;
    int i;
    double errs;
    BOOL covered;

    /* examples covered by later rules have been removed;
       thus to find relative errors, one can just find
       which examples are misclassified by this rule 
    */   

    errs = 0.0;
    index_rule((rule_t *)r); 
    for (i=0; i<vmax(data);i++) {
	exi = vref(example_t,data,i);
	covered = r!=NULL && indexed_rule_covers((rule_t *)r,exi->inst);
	if (covered && exi->lab==FALSE) {
	    errs += FP_cost;
	} else if (!covered && exi->lab==TRUE) {
	    errs += FN_cost;
	}
    } 
    return errs;
}

/* remove examples in data covered by r, updating allp and alln */
static void remove_covered_examples(refstate_t *r,vec_t *data,int *allp,int *alln)
{
    int i;
    example_t *exi;

    /* update the data by removing covered examples */
    index_rule((rule_t *) r); 
    i=0;
    while (i<vmax(data)) {
	exi = vref(example_t,data,i);
	if (indexed_rule_covers((rule_t *)r,exi->inst)) {
	    if (exi->lab) (*allp)--;
	    else (*alln)--;
	    swap_out_example(data,i);
	} else i++;
    } 
}

