/******************************************************************************
 flipper.h - main include file for flipper learning system
******************************************************************************/

#include "slog.h"

/* an example */

typedef struct example_s {
    vec_t *inst; /* a tuple */
    BOOL lab;    /* true if positive */
} example_t;

/* refinement operator */

typedef struct refop_s {
    lit_t *head;   
    vec_t *body;        /* vector of literals */
    symbol_t *fixing;   /* a variable to force to be a constant */
    vec_t *where;       /* a query */
    vec_t *assert;      /* vector of tuples */
} refop_t;

/* a vector of refinement operators */
extern vec_t *Ref_ops;

/* initial tuple database for refinement */ 
extern vec_t *Init_ref_tuples;

/* a state in the refinement graph 
 */

typedef struct refstate_s {
    BOOL top;
    int level;
    lit_t *head;        /* head of clause */
    vec_t *body;        /* body of clause */
    vec_t *tuples;      /* vector of associated facts */
    vec_t *body_space;  /* storage area for body */
    vec_t *tuple_space; /* storage area for tuples */
    int nposx;          /* #examples correctly covered */
    int nnegx;          /* #examples incorrectly covered */
    vec_t *body_len;    /* vector of lengths to which body can be pruned */
    vec_t *tuple_len;   /* vector of lengths to which tuples can be pruned */
    vec_t *choices;     /* number of choices at each step of refinement */
    symbol_t *fixing;   /* a variable to force to be a constant */
    vec_t *atleast;     /* require > atleast[n] proofs */
    struct refstate_s *next; 
                       /* for free list */   
} refstate_t, rule_t;

/* a concept--ie a predicate definition */
typedef struct concept_s {
    vec_t *rules;           /* vector of rule_t */
    int nposx,nnegx;        /* counts for default class */
} concept_t;

/****************************************************************************/

/* global parameters */

extern BOOL Simplify;              /* whether to use incremental REP */
extern double Max_decompression;   /* stopping criteria for adding rules */
extern int Optimizations;          /* times to optimize the ruleset */
extern double MDL_theory_factor;   /* to multiply coding cost of theory by */
extern double FN_cost;             /* cost of false negative */
extern double FP_cost;             /* cost of false positive */
extern int Class_counts[2];        /* distribution of data */
extern BOOL Number_restrictions;   /* use number restriction on clauses */
extern BOOL Tuple_values;          /* value function uses # proofs */
extern int Max_proofs;             /* max # proofs to allow per example */

#include "flipprotos.h"


