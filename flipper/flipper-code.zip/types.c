/******************************************************************************
 types.c - implement basic types: vector and atom
******************************************************************************/

#include <stdio.h>
#include <ctype.h>
#include "slog.h"

static BOOL needs_quote(char *);

/*****************************************************************************/

void fprint_symbol(fp,s)
FILE *fp;
symbol_t *s;
{
    if (s==NULL) fprintf(fp,"(null symbol)");
    else if (needs_quote(s->name) && s->kind!=NUMBER) fprintf(fp,"'%s'",s->name);
    else fprintf(fp,"%s",s->name);
}

void print_symbol(s)
symbol_t *s;
{
    fprint_symbol(stdout,s);
}


void show_symbol(s) /* debugging print function */
symbol_t *s;
{
    printf("[symbol%x name='%s' type=%d indx=%d]",
	   s,s->name,s->kind,s->index);
}

static BOOL needs_quote(char *str)
{

    if (isspecial(*str) && str[1]=='\0') {
	return FALSE;
    } else if (ispunct(*str)) {
	while (*++str) {
	    if (!ispunct(*str) || isspecial(*str)) 
	      return TRUE;
	} 
	return FALSE;
    } else if (isalpha(*str)) {
	while (*++str) {
	    if (!isalnum(*str) && (*str)!='_') {
		return TRUE;
	    } 
	}
	return FALSE;
    }
    return TRUE;
}

