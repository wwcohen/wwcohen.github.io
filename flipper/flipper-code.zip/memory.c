#include <stdio.h>

/*#define MALLOC_DEBUG*/

extern char *calloc(unsigned int,int);
extern int free(char *);

char *safe_calloc(n,size)
int n,size;
{
    char *space;
#ifdef MALLOC_DEBUG
    static int called_debug=0;
    if (!called_debug) {
	malloc_debug(2);
	called_debug=1;
    }
#endif

    space = calloc((unsigned)n,(unsigned)size);
    if (space==NULL) {
	fatal("out of memory");
    }
    return space;
}

safe_free(space)
char *space;
{
/*    free(space);*/
}

#ifdef TEST
main()
{
    int n=999,s=12;
    int c;
    
    for (c=0;safe_calloc(n,s)!=NULL;c++)
      ;
    printf("allocated %d times\n",c);
}
fatal(str)
char *str;
{
    fprintf(stderr,str);
}
#endif
