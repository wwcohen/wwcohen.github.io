/* main and mainaux functions */
extern char *add_ext(char *,char *);
extern void give_help(void);
extern int getopt(int,char **,char *);
extern char *optarg;
extern int optind;

/* dataset.c functions */
extern vec_t *ld_data(char *);
extern void fprint_example(FILE *,example_t *);
extern void fprint_data(FILE *,vec_t *);
extern void stratify_and_shuffle_data(vec_t *,int);
extern void stratified_partition(vec_t *,int,vec_t *,vec_t *);
extern void swap_out_example(vec_t *,int);
#define print_example(x) fprint_example(stdout,(x))
#define print_data(x) fprint_data(stdout,(x))

/* concept.c functions */
extern void fprint_concept(FILE *,concept_t *);
#define print_concept(x) fprint_concept(stdout,(x))
extern void fshow_concept(FILE *,concept_t *);
extern concept_t *ld_concept(char *);
extern int concept_size(concept_t *);
extern void free_concept(concept_t *);
extern BOOL classify(concept_t *,vec_t *);
extern BOOL classify_counts(concept_t *,vec_t *,int *, int *);
extern void count_concept(concept_t *, vec_t *);

/* rule.c functions */
extern void fprint_rule(FILE *,rule_t *);
#define print_rule(x) fprint_rule(stdout,(x))
extern void free_rule(rule_t *);
extern int rule_size(rule_t *);
extern rule_t *ld_rule(symbol_t *);
extern BOOL rule_covers(rule_t *,vec_t *);
extern BOOL indexed_rule_covers(rule_t *,vec_t *);
extern BOOL index_rule(rule_t *);
extern void unbind_indexed_rule(rule_t *);

/* fit.c functions */
extern vec_t *fit(vec_t *);

/* refine.c functions */
extern BOOL ld_refinements(char *);
extern fprint_refop(FILE *,refop_t *);
extern void print_refinements(void);
#define print_refop(x) fprint_refop(stdout,(x))

/* refstate.c functions */
extern refstate_t *copy_refstate(refstate_t *, refstate_t *);
extern refstate_t *new_refstate(void);
extern void clear_refstate(refstate_t *);
extern void free_refstate(refstate_t *refst);
extern void fprint_refstate(FILE *,refstate_t *);
#define print_refstate(x) fprint_refstate(stdout,(x))
extern void show_refstate(refstate_t *);
extern void refst_add_tuples(refstate_t *,vec_t *);
extern void refst_set_head(refstate_t *,lit_t *);
extern void refst_add_body(refstate_t *,vec_t *);

/* desref.c functions */
extern refstate_t *refinement_top(void);
extern void compute_designated_refinements(refstate_t *);
extern int n_designated_refinements(void);
extern refstate_t *refinement(int i);
void compute_designated_refinements(refstate_t *);
int n_designated_generalizations();
refstate_t *generalization(int);

/* value.c functions */
double value(refstate_t *,vec_t *,refstate_t *,int,double);
double information(int,int);
void count_examples(rule_t *,vec_t *,int *,int *);

/* mdl.c functions */
void reduce_dlen(vec_t *,vec_t *);
double ruleset_dlen(vec_t *,vec_t *,int,int);
double relative_compression(rule_t *,vec_t *,int,vec_t *);
