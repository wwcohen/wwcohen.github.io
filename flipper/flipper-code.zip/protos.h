/* lex.c functions */
extern BOOL lex_open(char *);
extern void lex_close(void);
extern int lex_line(void);
extern char *lex_file(void);
extern symbol_t *lex(void);
extern symbol_t *safe_lex(void);
extern symbol_t *last_lex(void);
extern void lex_verify(symbol_t *,symbol_t *);
#define isspecial(c) ((c)==',' || (c)=='.' || (c)=='(' || (c)==')')

/* intern.c functions */
extern symbol_t *intern(char *);
extern void show_hashtab(void);
extern symbol_t *make_constant(symbol_t *);
extern symbol_t *make_number(symbol_t *,double);
extern symbol_t *make_variable(symbol_t *);

/* types.c functions */
extern void fprint_symbol(FILE *,symbol_t *);
extern void print_symbol(symbol_t *);
extern void show_symbol(symbol_t *);

/* tuple.c functions */
BOOL ld_tuples(char *);
vec_t *ld_tuple(symbol_t *);
void add_tuple(vec_t *); 
void fprint_tuple(FILE *,vec_t *,BOOL);
void print_tuple(vec_t *,BOOL);
void show_tuples(void);

/* literal.c functions */
extern vec_t *ld_query(char *);
extern lit_t *ld_lit(symbol_t *);
extern symbol_t *lit_functor(lit_t *);
extern int lit_arity(lit_t *);
extern void subst_lit(lit_t *,symbol_t *,symbol_t *);
extern void fprint_lit(FILE *,lit_t *);
extern void fprint_query(FILE *fp,vec_t *);
extern void print_lit(lit_t *);
extern void print_query(vec_t *);
extern void show_lit(lit_t *);
extern void show_query(vec_t *);

/* prove.c functions */
extern BOOL prove(vec_t *,contfun_t,char *,char *);
extern BOOL slow_prove(vec_t *,vec_t *,contfun_t,char *,char *);
extern BOOL prove_tail(vec_t *,int,contfun_t,char *,char *);
extern BOOL index_query(vec_t *);
extern void unbind_indexed_query(vec_t *);

