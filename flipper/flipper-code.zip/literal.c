/******************************************************************************
 literal.c - i/o for literals and queries 
******************************************************************************/

#include <stdio.h>
#include "slog.h"

/*****************************************************************************/

vec_t *ld_query(char *file)
{
    symbol_t *tok;
    vec_t *query;
    lit_t *lit;
    
    query = new_vec(lit_t);

    if (!lex_open(file)) {
	error("can't open tuple file %s");
	return NULL;
    } else {
	tok=lex();
	if (!tok) return NULL;
	while (tok && tok!=Stop) {
	    lit = ld_lit(tok);
	    ext_vec(lit_t,query,lit);
	    tok = safe_lex(); /* adv to , or ? */
	    if (tok==Sep) tok=safe_lex();
	    else if (tok!=Stop) lex_error("expected ',' or '?'");
	}
	if (tok==NULL) lex_error("premature end of file"); 
	return query;
    }
}

lit_t *ld_lit(symbol_t *tok)
{
    lit_t *lit;
    vec_t *tup;
    int sign;

    lit = NULL;
    if (tok==Not || tok==Maybe_not) {
	sign = (tok==Not)? TRUE : MAYBE; 
	tok = safe_lex();
	tup = ld_tuple(tok);
	if (tup!=NULL) {
	    lit = newmem(1,lit_t);
	    lit->negated = sign;
	    lit->args = tup;
	}
    } else {
	tup = ld_tuple(tok);
	if (tup!=NULL) {
	    lit = newmem(1,lit_t);
	    lit->negated = FALSE;
	    lit->args = tup;
	}
    }
    return lit;
}

void fprint_lit(FILE *fp,lit_t *lit)
{
    int j;
    symbol_t *sij;

    if (lit==NULL) fprintf(fp,"(null literal)");
    else {
	if (lit->negated==TRUE) {
	    fprint_symbol(fp,Not);
	    fprintf(fp," ");
	} 
	if (lit->negated==MAYBE) {
	    fprint_symbol(fp,Maybe_not);
	    fprintf(fp," ");
	} 
	fprint_tuple(fp,lit->args,TRUE);
    }
}

void print_lit(lit_t *lit)
{
    fprint_lit(stdout,lit);
}

void fprint_query(FILE *fp,vec_t *query)
{
    int i;
    lit_t *liti;

    if (query==NULL) fprintf(fp,"(null query)");
    else {
	for (i=0; i<vmax(query); i++) {
	    liti = vref(lit_t,query,i); 
	    if (liti->ignore) fprintf(fp,"__");
	    else fprint_lit(fp,liti);
	    if (i!=vmax(query)-1) fprintf(fp,", ");
	}
    }
}

void print_query(vec_t *query)
{
    fprint_query(stdout,query);
}

void show_lit(lit_t *lit)
{
    int i;
    symbol_t *si;

    if (lit->ignore) printf("ign ");
    if (lit->builtin!=NULL) printf("sys ");
    if (lit->negated==TRUE) printf("\\+");
    if (lit->negated==MAYBE) printf("\\?");
    printf("<");
    for (i=0; i<vmax(lit->args); i++) {
	si = *vref(symbol_t *,lit->args,i);
	printf("%s",si->name);
	if (si->binding) printf(":%s ",si->binding->name);
	else printf(" ");
    }

    printf("+"); 
    if (lit->bound==NULL) {
	printf("null");
    } else {
	for (i=0; i<vmax(lit->bound);i++) 
	  printf(" %d",*vref(int,lit->bound,i));
    }
    printf(" -");
    if (lit->unbound==NULL) {
	printf("null");
    } else {
	for (i=0; i<vmax(lit->unbound);i++) 
	  printf(" %d",*vref(int,lit->unbound,i));
    }
    printf(">");
}

void show_query(vec_t *query)
{
    int i;
    lit_t *liti;

    if (query==NULL) printf("(null query)");
    else {
	for (i=0; i<vmax(query); i++) {
	    liti = vref(lit_t,query,i); 
	    show_lit(liti);
	    if (i!=vmax(query)-1) printf(", ");
	}
    }
}

/* substitute occurance of variable var with value val */
void subst_lit(lit_t *lit,symbol_t *var,symbol_t *val)
{
    int i;
    
    for (i=0; i<vmax(lit->args); i++) {
	if (*vref(symbol_t *,lit->args,i)==var) {
	    vset(symbol_t *,lit->args,i,&val);
	}
    }
}

symbol_t *lit_functor(lit_t *lit)
{
    if (lit==NULL) return NULL;
    else if (lit->args==NULL || vmax(lit->args)<=2) return NULL;
    else return *(vref(symbol_t *,lit->args,1));
}

extern int lit_arity(lit_t *lit)
{
    if (lit==NULL) return -1;
    else if (lit->args==NULL) return -1;
    else return vmax(lit->args)-2;
}
