/******************************************************************************
 slog.h - main include file for simple datalog
******************************************************************************/

#include <assert.h>
#include <limits.h>
#include <math.h>
#include "extras.h" 

#define REAL float
#define MAXREAL ((float)HUGE_VAL)
#define HUGEINT INT_MAX
#define NULLINDEX (-1)
#define BOOL int
#define FLAG char
#ifndef TRUE
#define FALSE 0
#define TRUE  1
#define MAYBE 2
#endif

/****************************************/

/* symbol type: a char string, plus some properties */
typedef enum { 
    OTHER=0,     /* type not yet determined */
    VARIABLE,
    CONSTANT,
    NUMBER
} sym_kind_t;

/* symbol structure
   - binding is NULL for unbound variable, self
     for constants and numbers
   - numval is set only for numbers
*/

typedef struct symbol_s {
    char *name;
    sym_kind_t kind;
    int index;
    struct symbol_s *binding;  
    REAL numval;
} symbol_t;

/* a tuple is a vector of symbol pointers
 * with the first symbol being a number
 * indicating tuple length
*/

/* a literal is a sign plus a tuple */
typedef struct lit_s {
    /* actual "substance" of the literal 
     */
    int negated;
    vec_t *args;

    /* stuff used by the theorem prover 
     */

    /* non-null iff literal corresponds to built-in predicate */
    BOOL (*builtin)(struct lit_s *);
    /* set if literal is for a built-in predicate */
    /* indices of previously-bound & unbound variables */
    vec_t *bound;
    vec_t *unbound;
    /* tell theorem prover to skip this literal */
    BOOL ignore;
} lit_t;

/* routine to handle a built-in predicate */
typedef BOOL (*builtin_fun_t)(lit_t *); 

/* a query is a vector of literals 
*/

/* the database is a vector of tuples All_tuples, plus some 
 * indexing information; the Max_arity of a DB tuple,
 * an Index, .....
*/

#define ARITY_BOUND 1000

extern vec_t *All_tuples;
extern int Max_arity;
extern vec_t ***Index;
extern int Max_indexed_const;
extern int Max_indexed_col;

/* number of vars and constants in database */

extern int Num_var;
extern int Num_const;

/* a "continuation function", to be passed to a theorem-prover */

typedef BOOL (*contfun_t)(char *,char *);

/*****************************************************************************/

/* keywords and special symbols */

extern symbol_t *Number[ARITY_BOUND];
extern symbol_t *Open_par,*Close_par,*Sep,*Stop,*Not,*Maybe_not,*Semi,*Gt;
extern symbol_t *Head,*Body,*Neck,*Assert,*Where,*Fixing,*InitDB;
extern symbol_t *Pos,*Neg;
extern symbol_t *Eq;

#include "protos.h"
