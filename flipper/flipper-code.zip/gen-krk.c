#include <stdio.h>

main(argc,argv)
int argc;
char *argv[];
{
    int i,j,m,pct_noise;
    int a,b,c,d,e,f,pos;

    if (argc<2) {
	fprintf(stderr,"syntax: %s <#-examples> <pct-noise>\n",argv[0]);
	exit(1);
    }

    m = atoi(argv[1]);
    pct_noise = atoi(argv[2]);

    /* print background relations */
    for (i=0; i<8; i++) 
      for (j=0; j<8; j++) 
	if (i<j) printf("lt(%d,%d).\n",i,j);
    for (i=0; i<8; i++) 
      for (j=0; j<8; j++) 
	if (adj(i,j)) 
	  printf("adj(%d,%d).\n",i,j);
    printf("\n");

    /* print examples */
    for (i=0;i<m;i++) {
	a = random()%8; b = random()%8;
	c = random()%8; d = random()%8;
	e = random()%8; f = random()%8;
	pos = illegal(a,b,c,d,e,f);
	if (random()%100 < pct_noise) pos = random()%2;
	printf("%sillegal(%d,%d,%d,%d,%d,%d).\n",
	       pos? "+" : "-",
	       a,b,c,d,e,f);
    }
}

illegal(a,b,c,d,e,f)
int a,b,c,d,e,f;
{
    if (adj(a,e) && adj(b,f)) return 1;
    else if (a==c && b==d) return 1;
    else if (a==e && b==f) return 1;
    else if (c==e && d==f) return 1;
    else if (c==e && (a!=c || !( (d<b && b<f) || (d>b && b>f)))) return 1;
    else if (d==f && (b!=d || !( (c<a && a<e) || (c>a && a>e)))) return 1;
    else return 0;
}

adj(x,y)
{
    return x==y || x==y+1 || x==y-1;
}
