/******************************************************************************
 mdl.c - description-length routines used (mostly) by fit.c
******************************************************************************/

#include <stdio.h>
#include "flipper.h"

/* locally used functions */

static double subset_dlen(int,double,double);
static double rule_dlen(rule_t *);
static BOOL delete_and_update(rule_t *,double *,int *,int *,int *,int *);
static double data_dlen(int,int,int,int);
static void count_ruleset(vec_t *,vec_t *,int *,int *,int *,int *);
static double replaced_ruleset_compression(rule_t *,vec_t *,int,
					   vec_t *,int *,int *,int *,int *);

/* to account for redundancy between attributes and conditions */
double MDL_theory_factor=1.0;    /* default */
#define REDUNDANCY_FACTOR 0.5

/****************************************************************************/

/* combined description length of the rules plus the data */
double combined_dlen(vec_t *rules,vec_t *data)
{
    int cov,uncov,fp,fn;
    double rule_bits;
    int i;
    rule_t *ri;

    count_ruleset(rules,data,&cov,&uncov,&fp,&fn);
    for (rule_bits=0,i=0; i<vmax(rules); i++) {
	rule_bits += rule_dlen(vref(rule_t,rules,i));
    }
    return rule_bits + data_dlen(cov,uncov,fp,fn);
}

/****************************************************************************/

/* compression obtained by inserting form into ruleset at position index  
 * relative to inserting a null-coverage rule in position index */

double relative_compression(refstate_t *rule,vec_t *rules,int index,vec_t *data)
{
    int cov,uncov,fp,fn; 
    double data_dlen_with,data_dlen_without;
    double comp_without,comp_with;
    double dlen_without,dlen_with;

    comp_without = 
      replaced_ruleset_compression(
         NULL,rules,index,data,&cov,&uncov,&fp,&fn);
    data_dlen_without = data_dlen(cov,uncov,fp,fn);

    comp_with = 
      replaced_ruleset_compression(
         rule,rules,index,data,&cov,&uncov,&fp,&fn);
    data_dlen_with = data_dlen(cov,uncov,fp,fn);

    dlen_without = data_dlen_without-comp_without;
    dlen_with = data_dlen_with+rule_dlen(rule)-comp_with;
    
    return dlen_without - dlen_with;
}

/****************************************************************************/

/* delete rules so as to reduce total description length */
void reduce_dlen(vec_t *rules,vec_t *data) /* rules is side-effected */ 
{
    int cov,uncov,fp,fn;
    BOOL need_recount;
    int i,j;
    rule_t *ri;
    int rcov;
    double compression;
    
    count_ruleset(rules,data,&cov,&uncov,&fp,&fn);
    need_recount=FALSE;

    /* look at all rules, latest first, and consider deletion */
    for (i=vmax(rules)-1; i>=0; i--) {
	ri = vref(rule_t,rules,i);
	if (delete_and_update(ri,&compression,&cov,&uncov,&fp,&fn)) {
	    trace(SUMM) {
		printf("// deleting r%d [saving %g bits]: ",
		       i+1,compression);
		print_rule(ri);
		printf("\n");
	    }
	    if (i!=vmax(rules)-1) need_recount=TRUE;
	    
	    /* delete the ri from rules */
	    free_rule(ri);
	    for (j=i; j+1<vmax(rules); j++) {
		vset(rule_t,rules,j,vref(rule_t,rules,j+1));
	    }
	    shorten_vec(rule_t,rules);
	}
    }
    if (need_recount) {
	count_ruleset(rules,data,&cov,&uncov,&fp,&fn);
    }
}


/***************************************************************************
 * locally used routines 
 ***************************************************************************/

/* compute coverage of a ruleset on a set of data */
static void count_ruleset(vec_t *rules,vec_t *data,
			  int *pcov,int *puncov,int *pfp,int *pfn)
/* will side-effect counts in rules after position index */
/* pcov, puncov, pfp, pfn are side-effected to hold computed counts */
{
    int cov,uncov,fp,fn;
    int i,j;
    BOOL covered; 
    example_t *exi;
    rule_t *rj;
    
    /* clear counts and index rules */
    cov = uncov = fp = fn = 0;
    for (j=0; j<vmax(rules); j++) {
	rj = vref(rule_t,rules,j);
	index_rule(rj); 
	rj->nposx = rj->nnegx = 0;
    }

    /* now count coverage on data of rules */
    for (i=0; i<vmax(data);i++) {
	exi = vref(example_t,data,i);
	/* see if some rule covers exi */
	for (covered=FALSE,j=0; j<vmax(rules) && !covered; j++) {
	    rj = vref(rule_t,rules,j);
	    if (indexed_rule_covers(rj,exi->inst)) {
		covered = TRUE;
		cov++;
		if (exi->lab==FALSE) {
		    fp++; 
		    rj->nnegx++;
		} else {
		    rj->nposx++;
		}
	    }
	} 
	if (!covered) {
	    uncov++;
	    if (exi->lab==TRUE) fn++;
	}
    } /* for datum i */
    
    /* return counts */ 
    *pcov = cov;
    *puncov = uncov;
    *pfp = fp;
    *pfn = fn;
}


/*****************************************************************************/

/* compute coverage of a ruleset[index..end] on data
 * after ruleset[index] has been replaced with a given form 
 * return compression obtained by deleting sub-optimal rules
*/
static double replaced_ruleset_compression(rule_t *replace,vec_t *rules,
					   int index,vec_t *data,
					   int *pcov,int *puncov,int *pfp,int *pfn)
/* replace is the rule to replace rules[index] or NULL for empty rule */
/* assume counts for rules 0...index-1 are ok */
/* assume data is the portion of larger set not covered by rules 0 ... index-1 */
/* *pcov,*puncov,*pfp,*pfn are side-effected to hold new counts*/ 
{
    int cov,uncov,fp,fn;
    int i,j;
    BOOL covered; 
    example_t *exi;
    rule_t *rj;
    double compj,compression;
    
    /* find out fp and coverage of early rules */
    cov = uncov = fp = fn = 0;
    for (j=0; j<index; j++) {
	rj = vref(rule_t,rules,j);
	/* index_rule(rj); */
	cov += rj->nnegx+rj->nposx;
	fp += rj->nnegx;
    } 
    /* clear counts for later rules */
    for (j=index+1; j<index; j++) {
	rj = vref(rule_t,rules,j);
	rj->nnegx = rj->nposx = 0;
    } 
    /* index rules */
    for (j=0; j<index; j++) {
	rj = vref(rule_t,rules,j);	
	index_rule(rj);
    }
    if (replace!=NULL) index_rule(replace);

    /* now count coverage on data of (later) rules */
    for (i=0; i<vmax(data);i++) {
	exi = vref(example_t,data,i);
	if (replace!=NULL && indexed_rule_covers(replace,exi->inst)) {
	    cov++; 
	    if (exi->lab==FALSE) fp++;
	} else {
	    /* see if later rule covers exi */
	    for (covered=FALSE,j=index+1; j<vmax(rules) && !covered; j++) {
		rj = vref(rule_t,rules,j);
		if (indexed_rule_covers(rj,exi->inst)) {
		    covered = TRUE;
		    cov++;
		    if (exi->lab==FALSE) {
			fp++; 
			rj->nnegx++;
		    } else {
			rj->nposx++;
		    }
		}
	    } 
	    if (!covered) {
		uncov++;
		if (exi->lab==TRUE) fn++;
	    }
	}
    } /* for datum i */
    
    /* now see if any rules can be deleted */
    compression = 0.0;
    for (j=index+1; j<vmax(rules); j++) {
	rj = vref(rule_t,rules,j);
	if (delete_and_update(rj,&compj,&cov,&uncov,&fp,&fn)) {
	    compression += compj;
	}
    }

    /* return counts */ 
    *pcov = cov;
    *puncov = uncov;
    *pfp = fp;
    *pfn = fn;

    return compression;
}


/****************************************************************************/

/* update counts as if rule were deleted 
 * also return (in pcompression) compression obtained by deletion and
 * (as return value) if the rule should be deleted
*/

static BOOL delete_and_update(rule_t *r,double *pcompression,
			      int *pcov,int *puncov,int *pfp,int *pfn)
/* *pcompression holds compression obtained by deletion */
/* *pcov, *puncov, *pfp, *pfn are updated to reflect deletion */
{
    int rcov,cov1,uncov1,fp1,fn1;
    double with,without;

    /* counts after deletion, assuming no other rules cover same data */
    cov1 = (*pcov) - (r->nnegx + r->nposx);
    uncov1 = (*puncov) + (r->nnegx + r->nposx);
    fp1 = (*pfp) - r->nnegx;
    fn1 = (*pfn) + r->nposx;

    with = data_dlen(*pcov,*puncov,*pfp,*pfn);
    without = data_dlen(cov1,uncov1,fp1,fn1);
    (*pcompression) = with + rule_dlen(r) - without;

    if ((*pcompression) >= 0.0) {
	/* update counts to reflect deletion */
	*pcov = cov1;
	*puncov = uncov1;
	*pfp = fp1;
	*pfn = fn1;
	return TRUE;
    } else {
	return FALSE;
    }
}


/****************************************************************************/

/* description length of the data given a ruleset---see (Quinlan,ML95) */
static double data_dlen(int cov,int uncov,int fp,int fn)
{
    double e,proportion;
    int i;

    assert(cov>0 || uncov>0); 


    /* desired proportion of fp/errors is same as proportion of class */
    proportion = Class_counts[TRUE]/(Class_counts[TRUE]+Class_counts[FALSE]);
    /* proportion = 0.5; */

    e = fn*FP_cost + fp*FP_cost;

    if (cov >= uncov) {
	return 
	  Log2(cov+uncov+1.0)+
	  subset_dlen(cov,fp*FP_cost,proportion*e/cov) + 
	  (uncov>0 ? subset_dlen(uncov,fn*FN_cost,(double)fn/uncov) : 0.0);
    } else {
	proportion = 1.0-proportion;
	return 
	  Log2(cov+uncov+1.0)+
	  subset_dlen(uncov,fn*FN_cost,proportion*e/uncov) + 
	  (cov>0 ? subset_dlen(cov,fp*FP_cost,(double)fp/cov) : 0.0);
    }
}


/****************************************************************************/

/* send subset of e elements of a set of size n, where expected number 
 * of such elements is n*p --- see (Quinlan,ML95) */
static double subset_dlen(int n,double e,double p)
/* error count e might be fractional due to weighting */
{
    return -Log2(p)*e + -Log2(1.0-p)*(n-e); 
}

/****************************************************************************/

static double rule_dlen(rule_t *r)
{

    int i;
    double chlen,dlen;

    dlen = 0.0;

    /* send each refinement choice individually */
    for (i=0; i<vmax(r->choices); i++) {
	chlen =  Log2((double) *vref(int,r->choices,i));
	if (chlen>1) chlen += 2*Log2(chlen);
	dlen += chlen;
    }

    return MDL_theory_factor * REDUNDANCY_FACTOR * dlen;
}

