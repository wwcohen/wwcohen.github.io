/****************************************************************************
 slog-main.c -- main program for a simple interpreter
 ***************************************************************************/

#include <stdio.h>
#include "slog.h"

extern int getopt(int,char **,char *);
extern char *optarg;
extern int optind;

static BOOL check_answer(char *,char *);

char *Help_str[] = {
    "syntax: slog [-vN] [-s] [-f file]",
    NULL
};

main(int argc,char *argv[])
{
    BOOL loaded,slow;
    int o;
    vec_t *query;
    BOOL proved;

    loaded = slow = FALSE;
    while ((o=getopt(argc,argv,"v:sf:"))!=EOF) {
	switch (o) {
	  case 'v': set_trace_level(atoi(optarg)); break;
	  case 's': slow=TRUE; break;
	  case 'f': loaded=ld_tuples(optarg); break;
	  case '?':
	  default:
	    fatal("bad option -%c",o);
	}
    }
    if (!loaded) {
	printf("enter tuple DB below, ending with EOF\n");
	loaded = ld_tuples(NULL);
    }

    printf("loaded %d tuples, %d constants, maxarity %d\n\n",
	   vmax(All_tuples),Num_const,Max_arity);

    if (!slow) index_tuples();

    if (loaded) {
	printf("query: ");
	while ((query=ld_query(NULL))!=NULL) {

	    trace(LONG) {
		printf("query was: ");
		fprint_query(stdout,query);
		printf(".\n");
	    }

	    if (slow) proved=slow_prove(query,All_tuples,&check_answer,(char *)query,NULL);
	    else proved=prove(query,&check_answer,(char *)query,NULL);

	    if (proved) printf("\nyes\n\n");
	    else printf("\nno\n\n");

	    trace (LONG) {
		printf("query is: ");
		show_query(query);
		printf(".\n");
	    }

	    printf("query: ");
	}
    }
}

static BOOL check_answer(char *arg1,char *dummy_arg) 
{
    int i;
    char ans[BUFSIZ];
    vec_t *query;

    query = (vec_t *)arg1;

    trace (LONG) {
	printf("full-answer: ");
	show_query(query);
	printf("\n\n");
    }
    printf("answer is: ");
    print_query(query);
    printf(" ");
    gets(ans);
    if (!ans[0] || ans[0]=='y' || ans[0]=='Y') return TRUE;
    else return FALSE;
}
