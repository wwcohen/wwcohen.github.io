/******************************************************************************
 ripper-main.c - main driver program for learning program
******************************************************************************/

#include <stdio.h>
#include <math.h>
#include "flipper.h"

/******************************************************************************/
char *Help_str[] = {
 "syntax: flipper [options] filestem",
 "",
 "options are:",
 " -v#      set trace level to #, which must be 0, 1, 2, or 3",
 " -n       expect noisy data (default)",
 " -c       expect clean data",
 " -r str  use refinement file str.ref (rather than stem.ref)",
 " -s      read data from stdin",
 "",  
 "other options:",
 " -O #    perform # optimization passes",
 " -P      print refinement rules and exit",
 " -M      max # proofs/example to allow",
 " -R      randomize operation",
 " -D #    set max decompression",
 " -S #    simplify hypothesis more (>1) or less (<1)",
 " -L #    set loss ratio to # (ratio=false-pos-cost/false-neg-cost),",
 "         where a 'positive' example is an instance of the minority class",
 " -T      base the value function on the number of proofs covered",
 "         rather than the number of examples covered",
 " -N      learn clauses than have an at-least number restriction",
 "",
 NULL
};


/*****************************************************************************/

int main(argc,argv)
int argc;
char *argv[];
{
    vec_t *train_data;
    char *stem="foo", *rstem=NULL;
    concept_t hyp;
    int o; 
    BOOL print_refinements_flag=FALSE;
    double loss_ratio;
    FILE *out_fp;
    BOOL randomize_seed=FALSE;
    BOOL use_stdin=FALSE;
    double tm;

    set_trace_level(NONE);

    while ((o=getopt(argc,argv,"v:ncr:sO:PRD:L:S:TNM:"))!=EOF) {
	switch (o) {
	  case 'v':
	    set_trace_level(atoi(optarg)); 
	    printf("option: trace level set to %d\n",trace_level());
	    break;
	  case 'n':
	    Simplify = TRUE;
	    printf("option: data is noisy\n");
	    break;
	  case 'c':
	    Simplify = FALSE;
	    printf("option: data is clean\n");
	    break;
	  case 'r':
	    rstem = newmem(strlen(optarg)+1,char);
	    strcpy(rstem,optarg);
	    printf("option: use refinement file '%s.ref'\n",rstem);
	    break;
	  case 's':
	    use_stdin = TRUE;
	    printf("option: read data from stdin\n");
	    break;
	  case 'M':
	    Max_proofs = atoi(optarg);
	    printf("option: clauses must have <= %d proofs/example\n",Max_proofs); 
	    break;
	  case 'O':
	    Optimizations = atoi(optarg);
	    printf("option: optimize %d time(s)\n",Optimizations);
	    break;
	  case 'S':
	    Simplify=TRUE;
	    MDL_theory_factor = atof(optarg);
	    printf("option: multiply coding cost of theory by %g\n",MDL_theory_factor);
	    break;
	  case 'D':
	    Max_decompression = atof(optarg);
	    printf("option: max decompression is %g\n",Max_decompression);
	    break;
	  case 'R':
	    randomize_seed=TRUE;
	    printf("option: will set random seed from clock\n");
	    break;
	  case 'L':
	    loss_ratio = atof(optarg);
	    FP_cost = 2.0*loss_ratio/(loss_ratio+1.0);
	    FN_cost = 2.0/(loss_ratio+1.0);
	    printf("option: ratio of cost of FP to cost of FN is %g:%g\n",
		   FP_cost,FN_cost);
	    break;
	  case 'T':
	    Tuple_values = TRUE;
	    printf("option: use tuple coverage in value function\n");
	    break;
	  case 'N':
	    Number_restrictions = TRUE;
	    printf("option: clauses will have a number restriction\n");
	    break;
	  case 'P':
	    /* printf("option: will echo grammar\n"); */
	    print_refinements_flag = TRUE;
	    break;
	  case '?':
	  default: 
	    give_help();
	    fatal("option not implemented");
	}
    }
    
    /* print out parameter settings */
    trace(SUMM) {
	printf("// parameter settings:\n");
	printf("//   expect %s data\n",Simplify?"noisy":"clean");
	if (Simplify) {
	    printf("//   optimize %d time(s)\n",Optimizations);
	    printf("//   max decompression is %g bits\n",
		   Max_decompression);
	}
	fflush(stdout);
    }

    if (optind<argc) {
	stem = argv[optind++];
	if (rstem==NULL) rstem=stem;
    } else {
	give_help();
	fatal("no file stem specified");
    }

    if (optind<argc) {
	warning("not all arguments were used: %s ...",argv[optind]);
    }

    start_clock(); 
    trace(SUMM) { 
	printf("// timing loading...\n"); 
	fflush(stdout);
    }
    if (use_stdin) {
	train_data = ld_data((char *)NULL);
    } else {
	train_data = ld_data(add_ext(stem,".data"));
    }
    if (!train_data) {
	fatal("no training data!");
    }

    if (!ld_refinements(add_ext(rstem,".ref"))) {
	fatal("error in loading refinement rules");
    }
    if (print_refinements_flag) {
	print_refinements();
	return 0;
    }
    
    if ((out_fp=fopen(add_ext(stem,".slog"),"w"))==NULL) {
	fatal("can't open output file");
    }

    tm = elapsed_time();
    trace(SUMM) {
        printf("// loaded %d examples in %.2f sec\n",
               vmax(train_data),tm); 
	fflush(stdout);
    }

    if (randomize_seed) randomize();

    trace(SUMM) {
	printf("// timing model command...\n"); 
	fflush(stdout);
    }
    start_clock(); 
    model(&hyp,train_data);
    tm = elapsed_time();
    trace(SUMM) printf("// model command took %.2f sec\n",tm);
    printf("Final hypothesis is:\n");
    print_concept(&hyp); fshow_concept(out_fp,&hyp);
    printf("===============================");
    printf(" summary ");
    printf("===============================\n");
    printf("Hypothesis size:   %d rules, %d conditions\n",
	   vmax(hyp.rules),concept_size(&hyp));
    printf("Learning time:     %.2f sec\n",tm);
}

