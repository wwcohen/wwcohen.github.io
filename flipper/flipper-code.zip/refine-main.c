#include <stdio.h>
#include "flipper.h"

static void update_info(vec_t *data,int *p,int *n,double *oldinfo)
{
    int i;
    example_t *exi;

    if (data) {
	(*p) = (*n) = 0; 
	for (i=0; i<vmax(data); i++) {
	    exi = vref(example_t,data,i);
	    if (exi->lab) (*p)++; else (*n)++; 
	}
	*oldinfo = information((*p),(*n));
    } else {
	(*p) = (*n) = 0;
	(*oldinfo) = 0.0;
    }
}

/****************************************************************************/

char *Help_str[] = { "syntax: refine -vN -r reffile -d datafile", NULL };

main(argc,argv)
int argc;
char *argv[];
{
    static refstate_t *curr,*next;
    int i,p,n,o;
    int nans;
    char ans[BUFSIZ];
    vec_t *data;
    double oldinfo,val;

    data = NULL;
    while ((o=getopt(argc,argv,"v:r:d:"))!=EOF) {
	switch (o) {
	  case 'v':
	    set_trace_level(atoi(optarg)); 
	    break;
	  case 'r':
	    ld_refinements(add_ext(optarg,".ref"));
	    break;
	  case 'd':
	    data = ld_data(add_ext(optarg,".data"));
	    break;
	  case '?':
	  default:
	    give_help();
	    fatal("bad option");
	}
    }
    if (optind<argc) {
	warning("not all arguments were used: %s ...",argv[optind]);
    }
    

    printf("***refinement ops are:\n");
    print_refinements();
    
    curr = refinement_top();
    update_info(data,&p,&n,&oldinfo);
    for (;;) {
	print_refstate(curr);
	printf("\nwhat> "); gets(ans);
	switch (ans[0]) {
	  case 'Q': case 'q':
	    exit(0);
	  case 'S': case 's':
	    show_refstate(curr);
	    break;
	  case 'R': case 'r':
	  case 'V': case 'v':
	    compute_designated_refinements(curr);
	    for (i=0; i<n_designated_refinements(); i++) {
		printf("ref %4d ",i);
		print_refstate(refinement(i));
		printf("\n");
		if (ans[0]=='V' || ans[0]=='v') {
		    if (data) {
			val = value(refinement(i),data,curr,n,oldinfo);
		    } else {
			fatal("no data");
		    }
		    printf("val %4g ",val);
		    print_refstate(refinement(i));
		    printf("\n");
		}
	    }
	    nans = -1;
	    while (nans >= n_designated_refinements() || nans<0 ) {
		printf("pick refinement ? "); scanf("%d",&nans);	    
	    }
	    copy_refstate(curr,refinement(nans));
	    break;
	  case 'G': case 'g':
	    compute_designated_generalizations(curr);
	    for (i=0; i<n_designated_generalizations(); i++) {
		printf("%2d ",i);
		print_refstate(generalization(i));
		printf("\n");
	    }
	    nans = -1;
	    while (nans >= n_designated_generalizations() || nans<0 ) {
		printf("pick generalization ? "); scanf("%d",&nans);	    
	    }
	    copy_refstate(curr,generalization(nans));
	    break;
	  case '?': case 'H': case 'h':
	  default:
	    printf("commands: quit,show,refine,generalize,values\n");
	}
    }
}


