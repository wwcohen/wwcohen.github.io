/******************************************************************************
 refine.c - read in refinement ops and apply them
******************************************************************************/

#include <stdio.h>
#include "flipper.h"

vec_t *Ref_ops=NULL;
vec_t *Init_ref_tuples=NULL;

/*****************************************************************************/

/* grammar
 *   refinements --> ref*
 *   ref --> refpart* '.'
 *   ref --> initdb lit {,lit}* '.'
 *   refpart --> headpart | bodypart | assertpart | wherepart | fixingpart
 *   headpart --> 'head' lit
 *   bodypart --> 'body' lit {,lit}* 
 *   fixingpart --> 'fixing' token
 *   assertpart --> 'assert' lit {,lit}* 
 *   wherepart --> 'where' lit {,lit}* 
 *
 * routines below are a recursive-descent parser
*/

static void ld_ref(symbol_t *);
static void ld_refpart(symbol_t *,refop_t *);
static void ld_headpart(symbol_t *,refop_t *);
static void ld_bodypart(symbol_t *,refop_t *);
static void ld_assertpart(symbol_t *,refop_t *);
static void ld_wherepart(symbol_t *,refop_t *);
static void ld_fixingpart(symbol_t *,refop_t *);
static void ld_ref_lits(symbol_t *,vec_t *);
static void ld_ref_tuples(symbol_t *,vec_t *);

BOOL ld_refinements(char *file)
{
    symbol_t *tok;

    Ref_ops = new_vec(refop_t);
    Init_ref_tuples = new_vec(vec_t *);

    if (!lex_open(file)) {
	error("can't open tuple file %s",file);
	return FALSE;
    } else {
	while ((tok=lex())!=NULL) {
	    ld_ref(tok);
	}
	return TRUE;
    }
}

static void ld_ref(symbol_t *tok)
{
    refop_t ref;
    vec_t *tup;

    if (tok==InitDB) {
	tok = safe_lex(); /* first token of lit */
	ld_ref_tuples(tok,Init_ref_tuples);
	lex_verify(safe_lex(),Stop);
    } else {
	ref.body = ref.where = ref.assert = NULL;
	ref.head = NULL;
	ref.fixing = NULL;
	do {
	    ld_refpart(tok,&ref);
	    tok = safe_lex();
	    /* printf("***tok==%s\n",tok->name); fprint_refop(stdout,ref); printf("\n"); */
	} while (tok!=Stop);

	if (!ref.body && !ref.head) 
	  error("refinement must include 'body' or 'head'");
	if (!ref.body) ref.body = new_vec(lit_t);
	if (!ref.assert) ref.assert = new_vec(vec_t *);
	if (!ref.where) ref.where = new_vec(lit_t);
	
	ext_vec(refop_t,Ref_ops,&ref);
    }
}

static void ld_refpart(symbol_t *tok,refop_t *ref)
{
    if (tok==Head) ld_headpart(tok,ref);
    else if (tok==Body) ld_bodypart(tok,ref);
    else if (tok==Assert) ld_assertpart(tok,ref);
    else if (tok==Where) ld_wherepart(tok,ref);
    else if (tok==Fixing) ld_fixingpart(tok,ref);
    else {
	lex_error("expected one of 'head','body','assert', or 'where'");   
	safe_lex();
    }
}

static void ld_headpart(symbol_t *tok,refop_t *ref)
{
    lit_t *lit;

    if (ref->head) lex_error("refinement can only have one 'head' part");

    tok = safe_lex();  /* start of literal */
    /* printf("calling ld_lit with token %s\n",tok->name); */
    lit = ld_lit(tok);
    ref->head = lit;
}

static void ld_bodypart(symbol_t *tok,refop_t *ref)
{
    if (ref->body) lex_error("only one 'body' clause per refinement");
    else ref->body = new_vec(lit_t);

    tok = safe_lex();  /* start literal */
    ld_ref_lits(tok,ref->body);
}

static void ld_assertpart(symbol_t *tok,refop_t *ref)
{
    if (ref->assert) lex_error("only one 'assert' clause per refinement");
    else ref->assert = new_vec(vec_t *);

    tok = safe_lex();  /* start literal */
    ld_ref_tuples(tok,ref->assert);
}

static void ld_wherepart(symbol_t *tok,refop_t *ref)
{
    if (ref->where) lex_error("only one 'where' clause per refinement");
    else ref->where = new_vec(lit_t);

    tok = safe_lex();  /* start literal */
    ld_ref_lits(tok,ref->where);
}

static void ld_fixingpart(symbol_t *tok,refop_t *ref)
{
    if (ref->fixing) lex_error("refinement can only have one 'fixing' part");
    tok = safe_lex();  /* variable */
    ref->fixing = tok;
}

/****************************************************************************/

static void ld_ref_lits(symbol_t *tok,vec_t *lits)
{
    ext_vec(lit_t,lits,ld_lit(tok));
    while ((tok=safe_lex())==Sep) {
	tok = safe_lex();  /* start of literal */
	ext_vec(lit_t,lits,ld_lit(tok));
    }
    unlex(tok);
}

static void ld_ref_tuples(symbol_t *tok,vec_t *tups)
{
    vec_t *tup;
    
    tup = ld_tuple(tok);
    ext_vec(vec_t *,tups,&tup);
    while ((tok=safe_lex())==Sep) {
	tok = safe_lex();  /* start of tuple */
	tup = ld_tuple(tok);
	ext_vec(vec_t *,tups,&tup);
    }
    unlex(tok);
}

/*****************************************************************************/

fprint_refop(FILE *fp,refop_t *ref)
{
    int i;

    if (ref->head!=NULL) {
	fprintf(fp,"\nhead\t"); 
	fprint_lit(fp,ref->head); 
    }
    if (ref->body && vmax(ref->body)>0) {
	fprintf(fp,"\nbody\t"); 
	fprint_query(fp,ref->body); 
    }
    if (ref->fixing) {
	fprintf(fp,"\nfixing\t"); 
	fprint_symbol(fp,ref->fixing); 
    }
    if (ref->where && vmax(ref->where)>0) {
	fprintf(fp,"\nwhere\t"); 
	fprint_query(fp,ref->where); 
    }
    if (ref->assert && vmax(ref->assert)>0) {
	fprintf(fp,"\nassert\t"); 
	for (i=0; i<vmax(ref->assert); i++) {
	    fprint_tuple(fp,*vref(vec_t *,ref->assert,i),FALSE);
	    if (i<vmax(ref->assert)-1) printf(",");
	}
    }
    printf(".");
}

void print_refinements()
{
    refop_t *ref;
    vec_t *tup;
    int i;

    printf("initdb\t");
    for (i=0; i<vmax(Init_ref_tuples); i++) {
	print_tuple(*vref(vec_t *,Init_ref_tuples,i),FALSE);
	if (i<vmax(Init_ref_tuples)-1) printf(", ");
    }
    printf(".\n");
    for (i=0; i<vmax(Ref_ops); i++) {
	ref = vref(refop_t,Ref_ops,i);
	fprint_refop(stdout,ref);
	printf("\n");
    }
}

#ifdef TEST
/*****************************************************************************/
/* main: test driver
*/

main(argc,argv)
int argc;
char *argv[];
{
    if (argc<=1) {
	ld_refinements(NULL);
    }
    else (ld_refinements(argv[1]));

    print_refinements();
}
#endif
