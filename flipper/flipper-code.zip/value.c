/******************************************************************************
 value.c - compute information gain and other statistics 
******************************************************************************/

#include <stdio.h>
#include "flipper.h"

/* true if there will be a number restriction associated with
 * every clause 
 */
BOOL Number_restrictions=FALSE;
/* true if the value function is computed in foil's way, based on
 * coverage of tuples, instead of by coverage of examples
 */
BOOL Tuple_values=FALSE;
/* maximum number of proofs allowed for any example
 */
BOOL Max_proofs = 0;

/* used for keeping track of variable bindings used in a proof */ 
typedef struct varstat_s {
    int max_index;
    int n_used;
    symbol_t *tofix;
    symbol_t **used_const;
    int *covpos;
    int *covneg;
    example_t **current_ex;
} varstat_t;

/* used for keeping track of how many proofs there are for each example */
typedef struct proofcount_s {
    BOOL lab;
    int n_proofs;
} proofcount_t;

static int compare_proofcount(pi,pj)
proofcount_t *pi,*pj;
{
    if (pi->n_proofs > pj->n_proofs) return 1;
    else if (pi->n_proofs == pj->n_proofs) return 0;
    else return -1;
}

static double information_gain(int,int,double);
static void count_examples_optimize(refstate_t *,refstate_t *,vec_t *,int *,int *,double);
static int opt_atleast(proofcount_t [],int,double, int *,int *,int *);
static void mark_irrelevant_literals(refstate_t *,refstate_t *);
static void alloc_varstat(varstat_t *);
static void init_varstat(varstat_t *,symbol_t *);
static BOOL store_var_stats_cont(char *, char *);
static BOOL count_proofs_cont(char *, char *);
static BOOL atleast_cont(char *, char *);
static BOOL null_cont(char *, char *);
static void setup_optimize(refstate_t *,refstate_t *,int *,symbol_t **,int *);

/*****************************************************************************/

double value(refstate_t *newst,vec_t *data,
	     refstate_t *prevst,int oldn,double old_info)
{
    int p,n,p1,n1;
    double val;

    trace(DBUG) {
	printf("// finding gain of:\n");
	print_refstate(newst);
	printf("\n");
    }

    count_examples_optimize(newst,prevst,data,&p,&n,old_info); 
    newst->nposx = p;
    newst->nnegx = n;
    if (oldn!=0) val = information_gain(p,n,old_info);
    else val = ((double) p)/vmax(newst->body);
  
    trace(DBUG) {
	printf("// gain of:\n"); 
	print_rule((rule_t *)newst); 
	printf(" = %g\n",val);

	/* a check */
	count_examples(newst,data,&p1,&n1);
	if (p1!=p || n1!=n) {
	    warning("something's wrong here! p1,p,n1,n=%d,%d,%d,%d",
		    p1,p,n1,n);
	}
	/* assert(p1==p && n1==n); */
    }

   

    return val;
}

static double information_gain(int p,int n,double old_info)
{
    return p*(old_info - information(p,n));
}

double information(int p,int n)
{
    if (p==0) return 0.0;
    else return Log2((p+n+1.0)/(p+1.0));
}

/* count the number of examples in data covered by the rule r */
void count_examples(refstate_t *r,vec_t *data,int *pos,int *neg)
{
/*
 * note: this routine has been written for efficiency, not
 * readability. the readable version is below
*/
#ifdef UNOPTIMIZED 
    int i;
    example_t *exi;

    *pos = *neg = 0;
    for (i=0; i<vmax(data); i++) {
	exi = vref(example_t,data,i);
	if (rule_covers((rule_t *)r,exi->inst)) {
	    if (exi->lab==TRUE) { 
		(*pos)++;
	    } else {
		(*neg)++;
	    }
	} 
    }
#else
    int i,j,k,p,n;
    int count;
    symbol_t *sk,*tk;
    BOOL well_formed,unifiable;
    example_t *exi,*exp,*end;
    int *bound,*unbound,n_bound,n_unbound,n_headargs;
    symbol_t **headargs,**insti;

    /* index the rule */
    well_formed = index_rule((rule_t *)r);

    /* cache out some properties of head */
    headargs = vbase(symbol_t *,r->head->args);
    n_headargs = vmax(r->head->args);
    n_bound = vmax(r->head->bound);
    n_unbound = vmax(r->head->unbound);
    bound = vbase(int,r->head->bound);
    unbound = vbase(int,r->head->unbound);

    p = n = 0; 

    if (well_formed) {

	/* loop over all examples */
	exp = vbase(example_t,data);
	end = exp + vmax(data);
	while (exp<end) {

	    exi = exp++;
	    insti = vbase(symbol_t *,exi->inst);

	    /* see if rule can unify with data */
	    unifiable = (n_headargs==vmax(exi->inst));

	    /* first check constraints */
	    for (j=0; unifiable && j<n_bound; j++) {
		k = bound[j];
		sk = headargs[k];
		tk = insti[k];
		if (sk->binding!=tk->binding) unifiable=FALSE;
	    }
	    /* now bind unbound variables */
	    for (j=0; unifiable && j<n_unbound; j++) {
		k = unbound[j];
		sk = headargs[k];
		tk = insti[k];
		sk->binding = tk->binding;
	    }
	    if (r->atleast && vmax(r->atleast)) {
		count = *vref(int,r->atleast,vmax(r->atleast)-1);
	    } else {
		count = 0;
	    }
	    if (unifiable 
		&& prove_tail(r->body,0,&atleast_cont,(char*)&count,NULL)) 
	    {
		if (exi->lab==TRUE) p++;
		else n++;
	    } 
	} /* for example i */

    } /* if well-formed */

    *pos = p;
    *neg = n;

    unbind_indexed_rule((rule_t *)r);
#endif
}

/****************************************************************************/

/* count examples covered by a rule, and if optimize is
   true, side-effect rule so as to optimize the gain

   side-effects include 'fixing' a variable by binding it
   to a constant; choosing a sign for a literal; and choosing
   the best number restriction
 */

static void count_examples_optimize(refstate_t *r,refstate_t *prev,vec_t *data,
				    int *pos,int *neg,double oldinfo)
{
    int i,j,k,p,n;
    symbol_t *sk,*tk;
    BOOL well_formed,unifiable;
    example_t *exi;
    int *bound,*unbound,n_bound,n_unbound,n_headargs;
    symbol_t **headargs,**insti;
    int maybe_posn,negated_posn;
    symbol_t *tofix; 
    int covpos,covneg,allpos,allneg;
    double pgain,ngain,best_gain;
    int best_negated,best_pos,best_neg;
    symbol_t *best_c,*c;
    lit_t *lit;
    contfun_t cont;
    static varstat_t varstat;
    static proofcount_t *proofcount=NULL;
    static int n_proofcount=0;
    int tmp_count;
    static BOOL first=TRUE;
    static BOOL count_proofs=FALSE;
    char *scratch_space;
    int th,n_thresh;

    /* figure out if we need to count the number of times
       each example can be proved 
    */
    count_proofs = Number_restrictions || Tuple_values || Max_proofs;

    /* allocate cache to hold variable stats */
    if (first) {
	alloc_varstat(&varstat);
	first = FALSE;
    }

    /* (re)allocate space to count proofs */
    if (Number_restrictions && n_proofcount<vmax(data)) {
	if (proofcount) freemem(proofcount);
	proofcount = newmem(vmax(data),proofcount_t);
	n_proofcount = vmax(data);
    }

    /* mark literals being used */
    if (!count_proofs) {
	mark_irrelevant_literals(r,prev); 
    }

    /* if we're trying to optimize over a class of queries, see if
     * it's possible, and modify the query by marking literals
     * redundant to this value computation
     */
    setup_optimize(r,prev,&maybe_posn,&tofix,&negated_posn);
    if (count_proofs && (tofix || maybe_posn!=NULLINDEX))
    {
	fatal("fixing or \? with -N, -T, or -M");
    }

    /* initialize any temp storage structures */
    if (tofix!=NULL) {
	/* when a variable needs to be fixed, we will collect all
	   proofs of each example, and record the value that the
	   variable took each time.  this is done by passing the
	   &store_var_stats function as a continuation to
	   prove_tail.  store_var_states accumulates the needed
	   information in the varstat array
	 */  
	cont = &store_var_stats_cont;
	init_varstat(&varstat,tofix);
	scratch_space = (char *) &varstat;
    } else if (count_proofs) {
	/* we want to count the number of proofs for each example
	   in order to determine the best threshold
	 */
	scratch_space = (char *) &tmp_count;
	cont = &count_proofs_cont;
    } else {
	cont = &null_cont;
    }

    /* index the rule */
    well_formed = index_rule((rule_t *)r);

    /* cache out some properties of the head */
    n_bound = vmax(r->head->bound);
    n_unbound = vmax(r->head->unbound);
    bound = vbase(int,r->head->bound);
    unbound = vbase(int,r->head->unbound);
    headargs = vbase(symbol_t *,r->head->args);
    n_headargs = vmax(r->head->args);

    covpos = covneg = allpos = allneg = 0; 

    /* compute coverage of the rule---or if optimizing, accumulate the
       information needed to set the free parameters properly 
    */
    if (well_formed) {

	/* loop over all examples exi, i=1...vmax(data) */
	for (exi=vbase(example_t,data),i=0; i<vmax(data); i++,exi++) {

	    insti = vbase(symbol_t *,exi->inst);

	    /* update count of pos/neg examples */
	    if (exi->lab==TRUE) allpos++;
	    else allneg++;

	    /* see if rule can unify with data */
	    unifiable = (n_headargs==vmax(exi->inst));

	    /* first bind unbound variables */
	    for (j=0; unifiable && j<n_unbound; j++) {
		k = unbound[j];
		sk = headargs[k];
		tk = insti[k];
		sk->binding = tk->binding;
	    }
	    /* now check constraints */
	    for (j=0; unifiable && j<n_bound; j++) {
		k = bound[j];
		sk = headargs[k];
		tk = insti[k];
		if (sk->binding!=tk->binding) unifiable=FALSE;
	    }
	    if (count_proofs) {
		tmp_count = 0;
		if (unifiable) {
		    prove_tail(r->body,0,cont,scratch_space,(char *)exi); 
		}
		if (Max_proofs && tmp_count>Max_proofs) {
		  /* mark this clause as useless and return */
		  *pos = *neg = 0;
		  if (tofix) tofix->binding = NULL;
		  unbind_indexed_rule((rule_t *)r);
		  return;
		}
		if (Tuple_values) {
		    if (exi->lab==TRUE) covpos += tmp_count;
		    else covneg += tmp_count;
		} else if (Number_restrictions) {
		    proofcount[i].n_proofs = tmp_count;
		    proofcount[i].lab = exi->lab;
		    if (tmp_count>0) {
			if (exi->lab==TRUE) covpos++;
			else covneg++;
		    }
		} else {
		    /* counted only for Max_proofs check */ 
		    if (tmp_count>0) {
		      if (exi->lab==TRUE) covpos++;
		      else covneg++;
		    }
		}
	    } else {
		/* not counting proofs */
		if (unifiable && 
		    prove_tail(r->body,0,cont,scratch_space,(char *)exi)) 
		{ 
		    if (exi->lab==TRUE) covpos++;
		    else covneg++;
		}
	    }
	} /* for example i */
    } /* if well-formed */

    /* chose the higest-gain literal in class being optimized over */
    if (!Number_restrictions && maybe_posn==NULLINDEX && !tofix) {
	/* the simplest case---nothing to optimize over */
	*pos = covpos;
	*neg = covneg;
    } else if (Number_restrictions) {
	assert(vmax(r->atleast));
	th = opt_atleast(proofcount,vmax(data),oldinfo,pos,neg,&n_thresh);
	vset(int,r->atleast,vmax(r->atleast)-1,&th);
	/* update number of choices */
	n = *vref(int,r->choices,vmax(r->choices)-1);
	n *= n_thresh;
	vset(int,r->choices,vmax(r->choices)-1,&n);
    } else if (maybe_posn!=NULLINDEX && !tofix) {
	lit = vref(lit_t,r->body,maybe_posn);
	pgain = information_gain(covpos,covneg,oldinfo);
	ngain = information_gain(allpos-covpos,allneg-covneg,oldinfo);
	if (pgain>=ngain) {
	    *pos = covpos;
	    *neg = covneg;
	    lit->negated = FALSE;
	} else {
	    *pos = allpos-covpos;
	    *neg = allneg-covneg;
	    lit->negated = TRUE;
	}
	/* update sign in literal */
	vset(lit_t,r->body,maybe_posn,lit);
	/* update number of choices */
	n = *vref(int,r->choices,vmax(r->choices)-1);
	n *= 2;
	vset(int,r->choices,vmax(r->choices)-1,&n);
    } else if (tofix) {
	best_gain = -MAXREAL;
	best_c = NULL;
	for (i=0; i<varstat.n_used; i++) {
	    c = varstat.used_const[i];
	    k = c->index;
	    if (negated_posn==NULLINDEX || maybe_posn!=NULLINDEX) {
		p = varstat.covpos[k];
		n = varstat.covneg[k];
		pgain = information_gain(p,n,oldinfo);
		trace (DBG1) {
		    printf("//   pgain %g (%d/%d) with %s=%s\n",
			   pgain,p,n,tofix->name,c->name);
		}
		if (pgain>best_gain) {
		    best_gain=pgain; best_c=c; best_negated=FALSE;
		    best_pos=p; best_neg=n;
		}
	    } 
	    if (negated_posn!=NULLINDEX || maybe_posn!=NULLINDEX) {
		p = allpos - varstat.covpos[k];
		n = allneg - varstat.covneg[k];
		ngain = information_gain(p,n,oldinfo);
		trace (DBG1) {
		    printf("//   ngain %g (%d/%d) with %s=%s\n",
			   pgain,p,n,tofix->name,c->name);
		}
		if (ngain>best_gain) {
		    best_gain=ngain; best_c=c; best_negated=TRUE;
		    best_pos=p; best_neg=n;
		}
	    }
	} /* for used constant i */
	/* set sign of literal, if it has been changed */
	i = NULLINDEX;
	if (negated_posn!=NULLINDEX) i=negated_posn; 
	else if (maybe_posn!=NULLINDEX) i=maybe_posn; 
	if (i!=NULLINDEX) {
	    lit = vref(lit_t,r->body,i);
	    lit->negated = best_negated;
	    vset(lit_t,r->body,i,lit);
	}
	/* bind the variable tofix to constant best_c in the clause */
	if (best_c == NULL) {
	    *pos = *neg = 0;
	} else {
	    *pos = best_pos;
	    *neg = best_neg;
	    /* insert the best constant, and update indices */
	    subst_lit(r->head,tofix,best_c);
	    for (i=0; i<vmax(r->body); i++) {
		subst_lit(vref(lit_t,r->body,i),tofix,best_c);
	    }
	    index_query(r->body);
	    /* update number of choices */
	    n = *vref(int,r->choices,vmax(r->choices)-1);
	    if (maybe_posn!=NULLINDEX) n *= 2; 
	    if (tofix) n *= varstat.n_used;
	    vset(int,r->choices,vmax(r->choices)-1,&n);
 	}
    } else {
	fatal("missing case in count_examples_optimize");
    }

    if (tofix) tofix->binding = NULL;
    unbind_indexed_rule((rule_t *)r);
}

/****************************************************************************/

/* stuff used by count_examples_optimize */

/* return the optimal 'atleast' value */
static int opt_atleast(proofcount_t proofcount[],int m, 
		       double oldinfo, int *pos, int *neg, int *n_thresh)
{
    int i;
    int num_pos,num_neg,num_pos_gt,num_neg_gt;
    int best_th, th;
    double best_val, val;

    /* count number of positive/negative examples */
    num_pos = num_neg = 0;
    for (i=0; i<m; i++) {
	trace (DBG1) { 
	    printf("// pc[%d] = %d (%c)\n",
		   i,proofcount[i].n_proofs,"ny"[proofcount[i].lab]);
	}
	if (proofcount[i].lab) num_pos++;
	else num_neg++;
    }
    /* sort by # proofs */ 
    qsort((char *)proofcount,m,sizeof(proofcount_t),&compare_proofcount);

    /* find best threshold (pilfered from mdb_opt.c in ripper code) */
    num_pos_gt = num_pos;
    num_neg_gt = num_neg;

    /* if everything has the same non-zero number of proofs, use the 
       threshold zero.  we need this since the first stage in the refinement
       is usually a clause with an empty body.
    */   
    if (proofcount[0].n_proofs>0 &&
	proofcount[0].n_proofs == proofcount[m-1].n_proofs) 
    {
	(*pos) = num_pos_gt;
	(*neg) = num_neg_gt;
	(*n_thresh) = 1;
	return 0;
    }
    best_val = -MAXREAL;
    best_th = -1;
    (*n_thresh) = 0;

    /* now explore the possible thresholds */
    for (i=0; i<m; ) {
	th = proofcount[i].n_proofs;
	(*n_thresh)++;
	/* find out how many things have n_proofs>th */
	while (i<m && proofcount[i].n_proofs==th)
	{
	    if (proofcount[i].lab) num_pos_gt--;
	    else num_neg_gt--;
	    i++;
	}
	/* now i points after last entry in pairs with n_proofs==th
	   num_[pos|neg]_gt applies to the new threshold; note if
	   this clause failed for everything then num_[pos|neg]gt are zero
	 */   
	val = information_gain(num_pos_gt,num_neg_gt,oldinfo);
	trace(DBUG) {
	    printf("// threshold %d: gt=%d/%d,val=%g\n",
		   th,num_pos_gt,num_neg_gt,val);
	}
	if (val >= best_val) {
	    best_val = val;
	    best_th = th;
	    (*pos) = num_pos_gt;
	    (*neg) = num_neg_gt;
	}
    } /* for i=0,..m */
    trace(DBUG) {
	printf("// threshold is %d [val=%g, %d/%d]\n",
	       best_th,best_val,(*pos),(*neg));
    }
    return best_th; 
}

/* figure out which variables in newst can be ignored */
static void mark_irrelevant_literals(refstate_t *newst,refstate_t *prevst)
{
    int i,j,k;
    lit_t *liti;
    symbol_t *sij;
    static vec_t *headvars=NULL;
    static vec_t *usedvars=NULL;
    BOOL vars_added;
    int lits_ignored;

    trace(DBG1) {
	printf("marking literals in:\n"); 
	print_refstate(newst);
	printf("\n"); 
    }

    if (headvars==NULL) {
	headvars = new_vec(symbol_t *);
	usedvars = new_vec(symbol_t *);
    }

    /* invariant: newst and oldst have identical heads, and
       newst has a body that is a prefix of prevst */

    /* start out assuming nothing is relevant but the new literals */
    for (i=0; i<vmax(prevst->body); i++) {
	liti = vref(lit_t,newst->body,i);
	liti->ignore = TRUE;
    }

    /* collect the variables in the head of the new clause */
    clear_vec(symbol_t *,headvars);
    for (j=0; j<vmax(newst->head->args); j++) {
	sij = *vref(symbol_t *,newst->head->args,j);
	if (sij->kind==VARIABLE && !vmem(symbol_t *,headvars,&sij)) {
	    ext_vec(symbol_t *,headvars,&sij);
	}
    }
    /* now find non-head variables in new part of clause */
    clear_vec(symbol_t *,usedvars);
    for (i=vmax(prevst->body); i<vmax(newst->body); i++) {
	liti = vref(lit_t,newst->body,i);
	for (j=0; j<vmax(liti->args); j++) {
	    sij = *vref(symbol_t *,liti->args,j);
	    if (sij->kind==VARIABLE
		&& !vmem(symbol_t *,headvars,&sij)
		&& !vmem(symbol_t *,usedvars,&sij))
	    {  
		ext_vec(symbol_t *,usedvars,&sij);
	    }
	}
    }

    trace(DBG1) {
	printf("head vars:"); 
	for (k=0; k<vmax(headvars); k++) {
	    printf(" ");
	    print_symbol(*(vref(symbol_t *,headvars,k)));
	}
	printf("\nused vars:"); 
	for (k=0; k<vmax(usedvars); k++) {
	    printf(" ");
	    print_symbol(*(vref(symbol_t *,usedvars,k)));
	}
	printf("\n");
    }



    /* mark relevant the literals constraining these variables */
    vars_added = (vmax(usedvars)>0);
    lits_ignored = vmax(newst->body)-1;
    while (vars_added && lits_ignored>0) {
	vars_added = FALSE;
	for (i=0; i<vmax(prevst->body); i++) {
	    /* see if liti constrains a used, non-head variable */
	    liti = vref(lit_t,newst->body,i);
	    for (j=0; 
		 !liti->negated && liti->ignore && j<vmax(liti->args); 
		 j++) 
	    {
		sij = *vref(symbol_t *,liti->args,j);
		if (sij->kind==VARIABLE 
		    && vmem(symbol_t *,headvars,&sij)) 
		{
		    liti->ignore = FALSE;
		    lits_ignored--;
		}
	    }
	    if (!liti->ignore) {
		/* record vars appearing here as "used" */
		for (j=0; j<vmax(liti->args); j++)  {
		    sij = *vref(symbol_t *,liti->args,j);		    
		    if (sij->kind==VARIABLE
			&& !vmem(symbol_t *,headvars,&sij)
			&& !vmem(symbol_t *,usedvars,&sij))
		    {
			ext_vec(symbol_t *,usedvars,&sij);			
			vars_added = TRUE;
		    }
		}

		trace(DBG1) {
		    printf("relevant [%i]: ",i); print_lit(liti);
		    printf("\nused vars:"); 
		    for (k=0; k<vmax(usedvars); k++) {
			printf(" ");
			print_symbol(*(vref(symbol_t *,usedvars,k)));
		    }
		    printf("\n");
		}


	    } /* if liti is relevant */
	} /* for lit i in possibly irrelevant part of body */
    } /* while vars_added */
}

/* allocate the varstat structure */
static void alloc_varstat(varstat_t *vs)
{
    vs->max_index = Max_indexed_const; 
    vs->used_const = newmem(Max_indexed_const,symbol_t *);
    vs->current_ex = newmem(Max_indexed_const,example_t *);
    vs->covpos = newmem(Max_indexed_const,int);
    vs->covneg = newmem(Max_indexed_const,int);
    vs->n_used = 0; 
}

/* initialize the varstat structure */
static void init_varstat(varstat_t *vs,symbol_t *tofix)
{
    int i,k;

    assert(vs->max_index==Max_indexed_const); 
    vs->tofix = tofix;
    for (i=0; i<vs->n_used; i++) {
	k = vs->used_const[i]->index;
	vs->covpos[k] = vs->covneg[k] = 0;
	vs->current_ex[k] = NULL;
    }
    vs->n_used = 0;
}


/* continuation that stores statistics on variable bindings */
static BOOL store_var_stats_cont(char *varstat_addr, char *ex_addr)
{
    int k;
    symbol_t *c;  
    example_t *ex;
    varstat_t *vs;

    vs = (varstat_t *) varstat_addr;
    ex = (example_t *) ex_addr;

    /* c is the value to which the variable to fix is bound */
    c = vs->tofix->binding;
    if (!c) {
	error("tofix not used in ref?");
	printf("example: "); 
	print_example(ex);
	printf("\ntofix: "); print_symbol(vs->tofix);
	printf("\n");
	return FALSE;
    }
    k = c->index;
    
    /* vs->current_ex[k] is the last example for which 
       c was a valid binding.  we'll only record a new
       binding for c if this is proof is associated with
       a new, different example.
    */   
    if (vs->current_ex[k]!=ex) {
	if (vs->current_ex[k]==NULL) {
	    vs->used_const[vs->n_used++] = c;
	    vs->covpos[k] = vs->covneg[k] = 0;
	}
	vs->current_ex[k] = ex;

	if (ex->lab) vs->covpos[k]++;
	else vs->covneg[k]++;
    }

    /* force backtracking */
    return FALSE;
}

/* continuation that stores statistics on variable bindings */
static BOOL count_proofs_cont(char *count_addr, char *ex_addr)
{
    int *count;

    count = (int *) count_addr;
    (*count)++;
    /* force backtracking */
    return FALSE;
}

/* continuation that requires k successes 
 * this is initially called with count_addr holding the integer k
*/
static BOOL atleast_cont(char *count_addr, char *ex_addr)
{
    int *count;

    count = (int *) count_addr;
    return ((*count)-- <= 0); 
}

/* a null continuation that just succeeds */
static BOOL null_cont(char *dummy1, char *dummy2)
{
    return TRUE;
}

/* store optimization info in maybe, tofix, negated 
   'tofix' is the variable to fix, or NULL
   'maybe' is position of any literal of the form \? or NULLINDEX
   'negated' is position of a negated literal that contains a variable to fix
*/
static void setup_optimize(refstate_t *r,refstate_t *prev,
			   int *maybe,symbol_t **tofix,int *negated)
{
    int i;
    lit_t *liti;
    int len;

    (*maybe) = (*negated) = NULLINDEX; 
    (*tofix) = r->fixing;
    len = vmax(r->body)-vmax(prev->body);
    for (i=0; i<vmax(r->body); i++) {
	liti = vref(lit_t,r->body,i);
	if (!liti->ignore) {
	    if (r->fixing && liti->negated==TRUE) {
		(*negated) = i;
		liti->negated = FALSE;
	    } else if (liti->negated==MAYBE) {
		(*maybe) = i;
		liti->negated = FALSE;
	    } 	
	    vset(lit_t,r->body,i,liti);
	}
    }
    if (*maybe!=NULLINDEX && len>1) {
	fatal("if \\? is used in a refinement, body must be of length 1");
    }
    if (*negated!=NULLINDEX && len>1)  {
	fatal("if 'fixing' is used in a refinement, body must be of length 1 or positive");
    }
}


