/******************************************************************************
 predict-slog-main.c --- make predictions with a slog hypothesis
******************************************************************************/

#include <stdio.h>
#include <math.h>
#include "flipper.h"

/******************************************************************************/
char *Help_str[] = {
 "syntax: predict-slog [options] filestem",
 "",
 "options are:",
 " -v#      set trace level to #, which must be 0, 1, 2, or 3",
 " -e       echo hypothesis",
 " -s       read data from stdin",
 NULL
};


/*****************************************************************************/

int main(argc,argv)
int argc;
char *argv[];
{
    vec_t *data;
    concept_t *c;
    char *stem="foo";
    BOOL echo=FALSE;
    BOOL use_stdin=FALSE;
    int o,i,p,n;
    example_t *exi;
    double tm;
    BOOL pred_class;

    set_trace_level(NONE);

    while ((o=getopt(argc,argv,"v:es"))!=EOF) {
	switch (o) {
	  case 'v':
	    set_trace_level(atoi(optarg)); 
	    printf("option: trace level set to %d\n",trace_level());
	    break;
	  case 'e':
	    echo = TRUE;
	    break;
	  case 's':
	    use_stdin = TRUE;
	    break;
	  case '?':
	  default: 
	    give_help();
	    fatal("option not implemented");
	}
    }
    
    if (optind<argc) {
	stem = argv[optind++];
    } else {
	give_help();
	fatal("no file stem specified");
    }

    if (optind<argc) {
	warning("not all arguments were used: %s ...",argv[optind]);
    }

    c = ld_concept(add_ext(stem,".slog"));
    if (echo) {
	print_concept(c);
	exit(0);
    } else {
	start_clock(); 
	trace(SUMM) { printf("// timing loading...\n"); }
	if (use_stdin) {
	    data = ld_data((char *)NULL);
	} else {
	    data = ld_data(add_ext(stem,".test"));
	}
	tm = elapsed_time();
	trace(SUMM) {
	    printf("// loaded %d examples in %.2f sec\n",
		   vmax(data),tm); 
	}
	if (!data) {
	    fatal("no data!");
	}
	for (i=0; i<vmax(data); i++) {
	    exi = vref(example_t,data,i);
	    pred_class = classify_counts(c,exi->inst,&p,&n);
	    printf("%c %d %d %c\n", 
		   "-+"[pred_class], p, n, "-+"[exi->lab]); 
	}
    } /* else !echo */
}
