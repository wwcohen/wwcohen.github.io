/******************************************************************************
 refstate.c - manipulate refstates
******************************************************************************/

#include <stdio.h>
#include "flipper.h"

/****************************************************************************/

/* allocating, freeing, and otherwise handling refstates
*/

static refstate_t *Free=NULL;

/* copy a refstate */
refstate_t *copy_refstate(refstate_t *dst, refstate_t *src)
{
    clear_refstate(dst);
    dst->top = src->top;
    dst->level = src->level;
    dst->fixing = src->fixing;
    refst_set_head(dst,src->head);
    refst_add_body(dst,src->body);
    refst_add_tuples(dst,src->tuples);
    copy_vec(int,dst->body_len,src->body_len);
    copy_vec(int,dst->tuple_len,src->tuple_len);
    copy_vec(int,dst->choices,src->choices);
    copy_vec(int,dst->atleast,src->atleast);
    return dst;
}

/* allocate a new refstate */
refstate_t *new_refstate()
{
    refstate_t *r;

    if (Free!=NULL) {
	r = Free; 
	Free = Free->next;
	r->next = NULL;
    } else {
	r = newmem(1,refstate_t);
	r->top = FALSE;
	r->level = NULLINDEX;
	r->head =  newmem(1,lit_t);
	r->head->args = new_vec(symbol_t *);
	r->body = new_vec(lit_t);
	r->body_space = new_vec(lit_t);
	r->fixing = NULL;
	share_vec(lit_t,r->body,r->body_space);
	r->tuples = new_vec(vec_t *);
	r->tuple_space = new_vec(vec_t *);
	share_vec(vec_t *,r->tuples,r->tuple_space);
	r->body_len = new_vec(int);
	r->tuple_len = new_vec(int);
	r->atleast = new_vec(int);
	r->choices = new_vec(int);
	r->nposx = r->nnegx = 0;
	r->next = NULL;
    }
    return r;
}

/* without releasing any storage, make a refstate appear empty */
void clear_refstate(refstate_t *r)
{
    int i;

    r->top = FALSE;
    r->level = NULLINDEX;
    clear_vec(symbol_t *,r->head->args);
    clear_vec(lit_t,r->body);
    for (i=0; i<vmax(r->body_space); i++)  
      clear_vec(symbol_t *,vref(lit_t,r->body_space,i)->args);
    r->fixing = NULL;
    clear_vec(int,r->atleast);
    clear_vec(vec_t *,r->tuples);
    for (i=0; i<vmax(r->tuple_space); i++)  
      clear_vec(symbol_t *,*vref(vec_t *,r->tuple_space,i));
    clear_vec(int,r->body_len);
    clear_vec(int,r->tuple_len);
    clear_vec(int,r->choices);
    r->next = NULL;
}

/* reclaim storage for a refstate */
void free_refstate(refstate_t *refst)
{
    clear_refstate(refst);
    refst->next = Free; 
    Free = refst->next;
}

/* print a refstate */
void fprint_refstate(FILE *fp,refstate_t *r)
{
    int i,n;

    fprint_lit(fp,r->head); 
    fprintf(fp,":-");
    fprint_query(fp,r->body);
    if (r->atleast) {
	fprintf(fp," >",n);
	for (i=0; i<vmax(r->atleast); i++) {
	    n = *vref(int,r->atleast,i);
	    fprintf(fp," %d",n);
	}
    }
    fprintf(fp,".");
}

/* show all information in a refstate */
void show_refstate(refstate_t *refst)
{
    int i;
    vec_t *tupi;
    int ni,n;

    if (refst->top) printf("TOP\n");
    printf("level:\t%d\n",refst->level);
    printf("pos/neg:\t%d/%d\n",refst->nposx,refst->nnegx);
    printf("head:\t"); print_lit(refst->head); printf("\n");
    printf("body:\t"); show_query(refst->body); printf("\n");
    printf("fixing:\t"); print_symbol(refst->fixing); printf("\n"); 
    if (refst->atleast && vmax(refst->atleast)) {
	n = *vref(int,refst->atleast,vmax(refst->atleast)-1);
	printf("atleast:\t%d\n",n);
    }
    if (refst->tuples==NULL) printf("tuples:\t(null)\n");
    else {
	printf("tuples:\t"); 
	for (i=0; i<vmax(refst->tuples); i++) {
	    tupi = *vref(vec_t *,refst->tuples,i);
	    print_tuple(tupi,FALSE); printf(" ");
	}
	printf("\n");
    }
    if (refst->body_len==NULL) printf("blen:\t(null)\n");
    else {
	printf("blen:\t"); 
	for (i=0; i<vmax(refst->body_len); i++) {
	    ni = *vref(int,refst->body_len,i);
	    printf("%d ",ni);
	}
	printf("\n");
    }
    if (refst->tuple_len==NULL) printf("tlen:\t(null)\n");
    else {
	printf("tlen:\t"); 
	for (i=0; i<vmax(refst->tuple_len); i++) {
	    ni = *vref(int,refst->tuple_len,i);
	    printf("%d ",ni);
	}
	printf("\n");
    }
    if (refst->choices==NULL) printf("choices:\t(null)\n");
    else {
	printf("choices:\t"); 
	for (i=0; i<vmax(refst->choices); i++) {
	    ni = *vref(int,refst->choices,i);
	    printf("%d ",ni);
	}
	printf("\n");
    }

}

/* copy in some tuples */
void refst_add_tuples(refstate_t *r,vec_t *moretups)
{
    int sz,i,j;
    vec_t *newtup,*tupi;
    symbol_t *sij;

    /* r->tuples is vector of tuples of r, as used by external routines */
    /* r->tuple_space is where copies of tuples will be stored */
    /* use share_vec to make them the same */

    sz = vmax(r->tuples)+vmax(moretups);
    /* grow space if necessary */
    while (vmax(r->tuple_space)<sz) {
	newtup = new_vec(symbol_t *);
	ext_vec(vec_t *,r->tuple_space,&newtup);
    }
    /* copy in tuples */
    for (i=0; i<vmax(moretups); i++) {
	tupi = *vref(vec_t *,moretups,i);
	newtup = *vref(vec_t *,r->tuple_space,i+vmax(r->tuples));
	clear_vec(vec_t *,newtup);
	for (j=0; j<vmax(tupi); j++) {
	    sij = *vref(symbol_t *,tupi,j);
	    if (sij->binding==NULL) 
	      ext_vec(symbol_t *,newtup,&sij);
	    else
	      ext_vec(symbol_t *,newtup,&(sij->binding));
	}
    }
    share_subvec(vec_t *,r->tuples,r->tuple_space,0,sz);
}

/* copy in a head */
void refst_set_head(refstate_t *r,lit_t *h)
{
    int i;
    symbol_t *si;
    clear_vec(symbol_t *,r->head->args);
    r->head->negated = h->negated;
    for (i=0; i<vmax(h->args); i++) {
	si = *vref(symbol_t *,h->args,i);
	if (si->binding==NULL) 
	  ext_vec(symbol_t *,r->head->args,&si);
	else 
	  ext_vec(symbol_t *,r->head->args,&(si->binding));
    }
}

/* copy in a body */
void refst_add_body(refstate_t *r,vec_t *morelits)
{
    int sz,i,j;
    vec_t *newtup,*tupi;
    lit_t *newlit, *liti;
    symbol_t *sij;

    sz = vmax(r->body)+vmax(morelits);
    /* grow space if necessary */
    while (vmax(r->body_space)<sz) {
	newlit = newmem(1,lit_t);
	newlit->args = new_vec(symbol_t *);
	ext_vec(lit_t,r->body_space,newlit);
    }
    /* copy in literals */
    for (i=0; i<vmax(morelits); i++) {
	liti = vref(lit_t,morelits,i);
	newlit = vref(lit_t,r->body_space,i+vmax(r->body));
	clear_vec(symbol_t *,newlit->args);
	newlit->negated = liti->negated;
	for (j=0; j<vmax(liti->args); j++) {
	    sij = *vref(symbol_t *,liti->args,j);
	    if (sij->binding==NULL) 
	      ext_vec(symbol_t *,newlit->args,&sij);
	    else
	      ext_vec(symbol_t *,newlit->args,&(sij->binding));
	}
    }
    share_subvec(lit_t ,r->body,r->body_space,0,sz);
}

