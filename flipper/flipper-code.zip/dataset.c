/******************************************************************************
 dataset.c - load and print datasets and examples
******************************************************************************/

#include <stdio.h>
#include "flipper.h"

/*****************************************************************************/

/* load a dataset--labeled training data and (unlabeled) background facts */

vec_t *ld_data(char *file)
{
    vec_t *data;
    symbol_t *tok;
    example_t ex;
    vec_t *tup;

    if (!lex_open(file)) {
	error("can't open data file %s",file);
	return NULL;
    }

    data = new_vec(example_t);
    while ((tok=lex())!=NULL) {
	if (tok==Pos || tok==Neg) {
	    /* an example */
	    ex.lab = (tok==Pos);
	    tok = safe_lex(); /* first token of instance */
	    ex.inst = ld_tuple(tok);
	    ext_vec(example_t,data,&ex);
	} else {
	    tup = ld_tuple(tok);
	    add_tuple(tup);
	}
	tok = safe_lex(); lex_verify(tok,Stop);
    }
    lex_close();
    index_tuples();
    return data;
}

/*****************************************************************************/

/* void print_example(example_t *ex): print an example
*/

void fprint_example(FILE *fp,example_t *ex)
{
    int i;
    
    printf(ex->lab? "+" : "-");
    fprint_tuple(fp,ex->inst,FALSE);
    fprintf(fp,".");
}

/* void print_data(vec_t *dataset): print a whole dataset
*/

void fprint_data(FILE *fp,vec_t *data)
{
    int i;
    
    if (!data) {
	fprintf(fp,"(null dataset)\n");
    } else {
	for (i=0; i<vmax(data); i++) {
	    fprint_example(fp,vref(example_t,data,i));
	    fprintf(fp,"\n");
	}
    }
}

/*****************************************************************************/

/* randomize order of data so as to preserve 
 * class frequencies in each of several partitions,
 * where partition i of size-n dataset is the range 
 *     n/splits*i...n/splits*(i+1)
 */
void stratify_and_shuffle_data(vec_t *data,int splits)
{
    int i,j,k,r,offset;
    static example_t *tmp=NULL, extmp, *exi;
    static int tmpsize=0,n;
    static int class_tmp[2];
    BOOL class;

    /* allocate class_tmp array if needed */

    /* allocate a larger tmp array, if needed */
    if (tmpsize<vmax(data)) {
	if (tmp) freemem(tmp);
	tmp = newmem(vmax(data),example_t);
	tmpsize = vmax(data);
    } 
    /* set logical size of tmp */
    n = vmax(data);

    /* count #examples of each class */
    class_tmp[FALSE]=class_tmp[TRUE]=0;
    for (i=0; i<n; i++) {
	exi = vref(example_t,data,i);
	class_tmp[exi->lab]++;
    }

    /* next, make class_tmp[i] be offset at which 
       to store examples of class i */   
    for (i=1; i>=0; i--) {
	offset = 0;
	for (j=0; j<i; j++) offset += class_tmp[j];
	class_tmp[i] = offset;
    }

    /* now copy in the data, sorting by class */
    for (i=0; i<n; i++) {
	exi = vref(example_t,data,i);
	offset = class_tmp[exi->lab]++;
	copy(example_t,&tmp[offset],exi);
    }

    /* shuffle each class separately */
    i=0;
    while (i<n) {
	class = tmp[i].lab;
	for (j=i; j<n && tmp[j].lab==class; j++)
 	    ; /* do nothing */
	if (j<n) {
	    /* shuffle range i...j */
	    for (k=i; k<j; k++) {
		r = k+random()%(n-k);
		copy(example_t,&extmp,&tmp[k]);
		copy(example_t,&tmp[k],&tmp[r]);
		copy(example_t,&tmp[r],&extmp);
	    }
	}
	i=j;	
    }

    /* store back into original array in set order */
    clear_vec(example_t,data);
    for (j=0; j<splits; j++) {
	for (i=j; i<n; i+=splits) {
	    ext_vec(example_t,data,&tmp[i]);
	}
    }
}

void stratified_partition(vec_t *data,int splits,vec_t *data1,vec_t *data2)
/* data1, data2 side effected */
{
    int cut;

    stratify_and_shuffle_data(data,splits);
    cut = vmax(data)*(splits-1.0)/splits;
    share_subvec(example_t,data1,data,0,cut);
    share_subvec(example_t,data2,data,cut,vmax(data)-cut);
}


/* mark i-th example as removed --- without destroying any data */
void swap_out_example(vec_t *data,int i)
{
    example_t *exi,*ex_last,tmp;

    exi = vref(example_t,data,i);
    ex_last = vref(example_t,data,vmax(data)-1);
    copy(example_t,&tmp,exi);
    copy(example_t,exi,ex_last);
    copy(example_t,ex_last,&tmp);
    shorten_vec(example_t,data);
}

#ifdef TEST
/*****************************************************************************/
/* main: test driver
*/

char *Help_str[] = {"syntax: testdata", NULL};

main(argc,argv)
int argc;
char *argv[];
{
    vec_t *data;

    data = ld_data(NULL);
    print_data(data);
    show_tuples();
}
#endif

