/******************************************************************************
 prove.c - a theorem prover for indexed Datalog with negation
******************************************************************************/

#include <stdio.h>
#include <ctype.h>
#include "slog.h"

/* routines for handling built-in predicates */
static builtin_fun_t builtin_fun(lit_t *);
static BOOL prove_eq(lit_t *);

/* locally used routines */
static BOOL slow_prove_tail(vec_t *,int,vec_t *,contfun_t,char *,char *);

/****************************************************************************/

/* a non-indexed theorem-prover */
BOOL slow_prove(vec_t *query,vec_t *db_tuples,
		contfun_t cont,char *a1,char *a2)
{
    BOOL ret;

    (void)index_query(query);
    ret = slow_prove_tail(query,0,db_tuples,cont,a1,a2);
    unbind_indexed_query(query);

    return ret;
}

/* workhorse routine for slow_prove */
static BOOL slow_prove_tail(vec_t *query,int place,vec_t *db_tuples,
			    contfun_t cont, char *a1,char *a2)
{
    lit_t *lit;
    symbol_t *si,*var,*value;
    int m,i,col;
    BOOL m_clashes;
    vec_t *tupm;
    BOOL bi_proof;
    builtin_fun_t bif;
    int n_bound,n_unbound;
    int *bound;
    int *unbound;
    
    if (place >= vmax(query)) {
	/* show answer and maybe force backtracking ... */
	return (*cont)(a1,a2);
    } else {
	lit = vref(lit_t,query,place);
	/* check if this is a built-in goal */
	if (lit->builtin!=NULL) {
	    return 
	      (*(lit->builtin))(lit)
		&& slow_prove_tail(query,place+1,db_tuples,cont,a1,a2);  
	}

	/* figure out columns of bound vars/constraints and unbound vars */
	n_bound = vmax(lit->bound);
	n_unbound = vmax(lit->unbound);
	bound = vbase(int,lit->bound);
	unbound = vbase(int,lit->unbound);

	m=0;
	while (m<vmax(db_tuples)) {
	    tupm = *vref(vec_t *,db_tuples,m);
	    m_clashes = (vmax(tupm)!=vmax(lit->args));
	    for (i=0; i<n_bound && !m_clashes; i++) {
		col = bound[i];
		value = (*vref(symbol_t *,lit->args,col))->binding;
		if (value != *vref(symbol_t *,tupm,col)) {
		    m_clashes = TRUE;
		}
	    }
	    if (!m_clashes) {
		/* tuple m matches */
		/* if literal is negated, fail */
		if (lit->negated) return FALSE;
		else {
		    /* bind free variables */
		    for (i=0; i<n_unbound; i++) {
			col = unbound[i];
			var = *vref(symbol_t *,lit->args,col);
			var->binding = *vref(symbol_t *,tupm,col);
		    }
		    if (slow_prove_tail(query,place+1,db_tuples,cont,a1,a2)) {
			return TRUE;
		    } 
		} /* else positive lit */
	    } 
	    m++;
	} /* while m<=vmax(db_tuples)  */

	/* all bindings exhausted */
	if (lit->negated) {
	    return slow_prove_tail(query,place+1,db_tuples,cont,a1,a2);
	} else {
	    /* unbind variables and fail */
	    for (i=0; i<n_unbound; i++) {
		col = unbound[i];
		var = *vref(symbol_t *,lit->args,col);
		var->binding = NULL;
	    }
	    return FALSE;
	}
    } /* if place<length */
}

/****************************************************************************/

/* an indexed theorem-prover */
BOOL prove(vec_t *query,contfun_t cont,char *a1,char *a2)
{
    BOOL ret;

    if (index_query(query)==FALSE) {
#ifdef UNOPTIMIZED
	trace(DBG1) { 
	    printf("prove[0]: badly formed query\n");
	}
#endif
	return FALSE;
    } else {
	ret = prove_tail(query,0,cont,a1,a2);
	/* if proof failed, backtracking
	   will have unbound variables, but
	   if proof succeeded, some variables
	   will have new bindings... */
	if (ret) unbind_indexed_query(query);
	return ret;
    }
}

/* workhorse routine for prove---made external for efficiency 
 * reasons (sometimes it's best to sidestep prove...)
*/
BOOL prove_tail(vec_t *query,int place,contfun_t cont,char *a1,char *a2)
{
    lit_t *lit;
    int n_bound,n_unbound;
    int *bound;
    int *unbound;
    int *candidates[ARITY_BOUND];
    int nextc[ARITY_BOUND];
    int n_candidates[ARITY_BOUND];
    symbol_t *si,*var;
    int m,i,j,next_m,col;
    BOOL m_can_match,matches_possible;
    vec_t *matching_tup;
    BOOL bi_proof;
    builtin_fun_t bif;
    
    if (place >= vmax(query)) {
	/* show answer and maybe force backtracking ... */
	return (*cont)(a1,a2);
    } else {

	/* figure out which literal needs to be proved 
	*/   
	lit = &vbase(lit_t,query)[place];

#ifdef UNOPTIMIZED
	trace(DBG1) {
	    printf("prove[%d]: ",place);
	    print_lit(lit);
	    printf("\n");
	}
#endif

	if (lit->ignore) {
	    return prove_tail(query,place+1,cont,a1,a2);
	}

	/* check if this is a built-in goal */
	if (lit->builtin!=NULL) {
	    bi_proof = (*(lit->builtin))(lit);
#ifdef UNOPTIMIZED
	    trace(DBG1) {
		printf("builtin[%d]: ",place);
		print_lit(lit);
		if (bi_proof) printf("---ok\n"); 
		else printf("---fails\n");
	    }
#endif
	    return bi_proof && prove_tail(query,place+1,cont,a1,a2);  
	}

	/* columns of bound vars/constraints and unbound vars */
	n_bound = vmax(lit->bound);
	n_unbound = vmax(lit->unbound);
	bound = vbase(int,lit->bound);
	unbound = vbase(int,lit->unbound);

	/* candidates[j] is a vector of all possible tuples
	   that the constant in position bound[j], 
	   and nextc[j] is a pointer into this vector
	*/
	for (j=0; j<n_bound; j++) {
	    i = bound[j];
	    si = vbase(symbol_t *,lit->args)[i];
	    candidates[j] = vbase(int,Index[si->binding->index][i]);
	    n_candidates[j] = vmax(Index[si->binding->index][i]);
	    nextc[j] = 0;
	}

	/* scan for a tuple that satisfies constraints imposed by
	   the bound vars (ie "matches").  
	*/   
	m = 0;
	matches_possible = TRUE;

	while (m<vmax(All_tuples) && matches_possible) {
	    /* see if the tuple at position m matches 
	     */
	    m_can_match = TRUE;
	    for (i=0; i<n_bound && m_can_match; i++) {
		/* look for a matching candidate tuple for var i 
		 */
		while (nextc[i] < n_candidates[i] &&  
		       candidates[i][nextc[i]] < m) 
		{
		    nextc[i]++;
		}
		if (nextc[i] >= n_candidates[i]) {
		    /* if all candidates fail then give up */
		    m_can_match = FALSE;
		    matches_possible = FALSE;
		} else {
		    /* next_m is the next tuple possible, considering
		       bound variable i only; also next_m >= m
		    */
		    next_m = candidates[i][nextc[i]];
		    if (next_m>m) {
			/* no tuples <= m satisfy var i's constraint */
			m_can_match = FALSE;
		    } 
		}
	    } /* for i */ 

	    if (!m_can_match) {
		/* m couldn't match; however matching tuples with
		   indices of next_m or higher are possible 
		*/   
		m = next_m;
	    } else {
		/* tuple m matches */
		/* if literal is negated, fail */
		if (lit->negated) return FALSE;
		else {
		    /* bind free variables */
		    matching_tup = vbase(vec_t *,All_tuples)[m];
		    for (i=0; i<n_unbound; i++) {
			col = unbound[i];
			var = vbase(symbol_t *,lit->args)[col];
			var->binding = vbase(symbol_t *,matching_tup)[col];
		    }
		    /* finally see if the remainder of the query succeeds 
		     */
#ifdef UNOPTIMIZED
		    trace(DBG1) {
			printf("match[%d]: ",place);
			print_lit(lit);
			printf(" -at tuple %d\n",m);
		    }
#endif
		    if (prove_tail(query,place+1,cont,a1,a2)) {
			return TRUE;
		    } else {
#ifdef UNOPTIMIZED
			trace(DBG1) {
			    printf("redo[%d]:  ",place);
			    print_lit(lit);
			    printf("\n");
			}
#endif
			m++;
		    }
		} /* else positive lit */
	    } 
	} /* while m */

	/* all bindings exhausted */

	if (lit->negated) {
	    /* see if remainder of query succeeds */
#ifdef UNOPTIMIZED
	    trace(DBG1) {
		printf("fails[%d]: ",place);
		print_lit(lit);
		printf("\n");
	    }
#endif
	    return prove_tail(query,place+1,cont,a1,a2);
	} else {
	    /* unbind variables and fail */
	    for (i=0; i<n_unbound; i++) {
		col = unbound[i];
		var = vbase(symbol_t *,lit->args)[col];
		var->binding = NULL;
	    }
#ifdef UNOPTIMIZED	    
	    trace (DBG1) {
		printf("fails[%d]: ",place);
		print_lit(lit);
		printf("\n");
	    }
#endif
	    return FALSE;
	}
    } /* if place<length */
}

/****************************************************************************/

/* handle built-in goals 

   current built in: = (equality)
*/ 

static builtin_fun_t builtin_fun(lit_t *lit)
{
    if (vmax(lit->args)==4 &&
	*vref(symbol_t *,lit->args,1)==Eq) 
    {
	return &prove_eq;
    }
    return NULL;
}

static BOOL prove_eq(lit_t *lit)
{
    symbol_t *f,*a,*b;

    a = *vref(symbol_t *,lit->args,2);
    b = *vref(symbol_t *,lit->args,3);

    if (a->binding && b->binding) {
	if (a->binding==b->binding) return !(lit->negated);
	else return lit->negated;
    } else if (a->binding && !b->binding) {
	if (lit->negated) return FALSE;
	else {
	    b->binding = a->binding;
	    return TRUE;
	}
    } else if (!a->binding && b->binding) {
	if (lit->negated) return FALSE;
	else {
	    a->binding = b->binding;
	    return TRUE;
	}
    } else   { /* both unbound */
	print_lit(lit);
	warning("redundant use of equality when both X and Y are unbound");
	return !(lit->negated); 
    }
}

/****************************************************************************/

/* add extra information to the query that will be used in theorem-proving 
 * return TRUE if "well-formedness" checks succeed, ie if the query has
 * a chance of succeeding when used with the *indexed* tuple database
*/

BOOL index_query(vec_t *query)
{
    int i,j,k;
    lit_t *liti;
    symbol_t *sij;
    BOOL well_formed;
    
    well_formed = TRUE;

    /* go through and record locations of bound/unbound variables */
    for (i=0; i<vmax(query); i++) {

	liti = vref(lit_t,query,i);

	liti->builtin = builtin_fun(liti);

	if (liti->ignore==FALSE) {

	    if (liti->builtin==NULL && vmax(liti->args) > Max_indexed_col) {
		well_formed = FALSE;
	    }
	    if (liti->negated==MAYBE) {
		well_formed = FALSE;
	    }

	    if (!liti->bound) liti->bound  =  new_vecn(int,vmax(liti->args));
	    else clear_vec(int,liti->bound);
	    if (!liti->unbound) liti->unbound  =  new_vecn(int,vmax(liti->args));
	    else clear_vec(int,liti->unbound);

	    for (j=0; j<vmax(liti->args); j++) {
		sij = *vref(symbol_t *,liti->args,j);
		if (sij->binding!=NULL) {
		    ext_vec(int,liti->bound,&j);
		    if (liti->builtin==NULL && 
			sij->binding->index > Max_indexed_const) 
		    {
			well_formed = FALSE;
		    }
		} else {
		    ext_vec(int,liti->unbound,&j);
		    /* bind this variable something to simulate
		       the condition that will hold in during proving */
		    sij->binding = Number[0];
		}
	    } /* for argument j */
	    if (liti->negated) {
		/* unbind the free variables */ 
		for (k=0; k<vmax(liti->unbound); k++) {
		    j = *vref(int,liti->unbound,k);
		    sij = *vref(symbol_t *,liti->args,j);
		    sij->binding = NULL;
		}
	    }
	} /* if not built-in predicate */
    } /* for literal i in query */

    /* unbind all the proper variables */
    unbind_indexed_query(query);

    /* return TRUE if the query has a chance of succeeding */
    return well_formed;
}

/* unbind variables that might have been bound in theorem-proving */
void unbind_indexed_query(vec_t *query)
{
    int i,j,k;
    lit_t *liti;
    symbol_t *sik;
    
    /* go through and unbind variables marked as "unbound" */
    for (i=0; i<vmax(query); i++) {
	liti = vref(lit_t,query,i);
	if (liti->unbound) {
	    for (j=0; j<vmax(liti->unbound); j++) {
		k = *vref(int,liti->unbound,j);
		sik = *vref(symbol_t *,liti->args,k);
		sik->binding = NULL;
	    }
	}
    }
}

