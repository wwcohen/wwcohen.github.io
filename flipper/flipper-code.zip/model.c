/******************************************************************************
 model.c - use fit() to find a model that fits the data
******************************************************************************/

#include <stdio.h>
#include "flipper.h"

static void count_classes(vec_t *);

int Class_counts[2];

/*****************************************************************************/

void model(hyp,data)
concept_t *hyp;           /* hypothesis returned here */
vec_t *data;
{
    count_classes(data);
    hyp->rules = fit(data);
    count_concept(hyp,data);
}

/****************************************************************************/

/* count #examples of each class, for use by MDL, etc */
static void count_classes(data)
vec_t *data;
{
    int i;
    example_t *exi;

    Class_counts[FALSE] = Class_counts[TRUE] = 0;
    for (i=0; i<vmax(data); i++) {
	exi = vref(example_t,data,i);
	Class_counts[exi->lab]++;
    }
    trace (SUMM) {
	printf("// class frequencies: %d total, %d pos, %d neg\n",
	       vmax(data),Class_counts[TRUE],Class_counts[FALSE]);
    }
}

