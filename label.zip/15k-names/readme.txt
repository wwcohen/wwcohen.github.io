Task: label all person names in the accompanying files. This is a
first subset of a total corpus of about 15,000 messages (of which
probably not all need to be labeled).

Definition of person names:

 - Do count nicknames ("Ed and I will...") and misspelled names ("Tell Aron not to worry about...").

 - Don't count names that are part of an email (eg william in "william.cohen@cmu.edu", or
 andrew in "cyu@andrew.cmu.edu") 

 - Don't include names of organizations or places, even if they 'could have been' people
names (eg "let's watch the Mario Lemiux Invitational tonite", or "my girlfriend graduated from
Robert Morris last spring")

There may be (probably are) some other boundary cases for names that I
haven't thought of.  If you see any, write them down, and fire off
some email to me (wcohen@cs.cmu.edu) and each other
(amobley@andrew.cmu.edu, cyu@andrew.cmu.edu).  The most important
thing is not so much how boundary decisions are made, but that they're
made the same way everytime: you need to be consistent - with each
other, and with yourself.  

Remember, computers are not smart.  To be successful at training them
it's key to provide an accurate, consistent signal.  Be aware also
that you'll see some mistakes that a person would never make.  Work
carefully, and take a break if you feel yourself zoning out.

==============================================================================
Operating the labeler
==============================================================================

KB shortcuts:
  control I = importButton
  control E = exportButton
  control S = exportButton
  control A = addButton
  DELETE = deleteButton
  control D = deleteButton
  LEFT = prevButton
  control B = prevButton
  RIGHT = nextButton
  control F = nextButton
  TAB = nextButton

A gotcha: internally, the labeler maintains a list of "spans", which
are substrings of an email msg.  Sometimes you might have two spans
that overlap each other, for instance

  You might see [a <sentence] that> was computer-labeled like this:

where [a sentence] was one "span" and <sentence that> was another.
The labeler will just highlight 'a sentence that', so it will look
like one long span, until you start using the next button.

==============================================================================
Background on the email data, from Bob Kraut:
==============================================================================

About the context of the email databases. These are email from
approximately 20 teams of MBA students playing CMU's Management Game
over a 7 week period.  I got the following text from a alumni article:

"The Management Game is an applied strategic management exercise where
teams of students operate simulated manufacturing companies for 2-3
years [over the course of one semester] acting as senior
management. Groups of students compete against each other in multiple
countries as they try to add value to their companies."

The student players were given roles as the executive leadership of a
soap manufacturing company. Each team received the same historical
data and started at the same initial stage. Using a "multi-campus,
multi-country computer simulation," Game generated marketplace
scenarios for each team (e.g., inventory problems, competitive
pressures, expansion opportunities, demand) based primarily on the
collective decisions of the market; that is, the results of a team's
decisions are based on the decisions of the other teams.

In a series of presentations to their external boards, the
'executives' have to defend their actions and explain their
strategies. This was an imposing task in itself, plus a significant
portion of the team's grade was based on its board's reviews and
compensations. "

I've attached some text from a paper that Sue and I are writing. The
methods section describes the Game context in a little more detail:

"We examined these hypotheses in the context of a realistic business
simulation called the Management Game (Cohen, Dill, Kuehn, & Winters,
1964).  Participants consisted of 277 MBA students, organized into 50
teams.  Students had from zero to 27 years prior work experience (M =
4.62; sd = 3.12). Approximately one-third were women.

Teams of five or six MBA students competed with each other running
soap companies over a 14-week period.  During the first seven weeks,
students organized teams and learned about the simulation, and during
the second period they actually played the game.  Students were placed
on teams through a two-stage draft. First, students exchanged resumes
describing skills, task preferences, and work experience. Based on a
popular vote, the class as a whole elected 50 team presidents.  These
presidents subsequently selected members for their teams through a
round-robin draft.

Students acted as the senior managers of a consumer product company
during a simulated two-year business period.  They made decisions
regarding the nature, production, distribution, and financing of their
products--laundry detergents. For example, they decided what
combina-tions of price, cleaning power, and environmental friendliness
their detergents should have, how much to manufacture, which regions
of the country to target, what manufacturing capacity they should
maintain, and how large their stock dividends should be.  During three
separate reviews, each team presented its company's strategies and
accomplishments to its board of directors, composed of local business
executives.  As individuals, all students participated in a stock
mar-ket, trading shares of the simulated companies to amass personal
wealth.

Except for the appointment of its president, each team had discretion
on how they would be internally organized.  Most teams adopted a
functional division of labor, with different indi-viduals responsible
for the core functions of research and development, finance,
marketing, pro-duction and the presidency of the company.  Each team
member was responsible for finding, analyzing, and drawing conclusions
from a large body of information, which had to be integrated with
information developed by other roles to make decisions.  For example,
early in the simula-tion, Vice Presidents of Marketing typically
decided how much money to spend on simulated market research programs
about the consumers' preferences; they executed these programs and
interpreted the results.

The responsibilities for acquiring and analyzing other information
were more diffuse. For example, most team members would be involved in
the basic strategic decision to produce a low cost/low quality product
or a high cost/premium one. In addition, most team members examined
publicly available financial data about other firms and sought out
classroom gossip to assess their competitor's strategies. Most
business decisions they made were highly interdependent, requiring a
high degree of coordination among team members.  For example,
marketing decisions about consumer preferences had to be integrated
with research and development information about product formula and
production decisions about plant capacities.  Approximately twice a
week each team recorded decisions for that period (e.g., about the
pricing of products in different markets, the attributes of products,
the level of production in sev-eral factories, the sources of
financing for their operations, etc.) and received feedback from a
computer simulation about their sales, market share, profitability and
other key business indica-tors.

Each team met with a separate board of directors three times over a
seven-week period. Each board of directors consisted of four or five
local business executives or managers.  In preparation for each
meeting, the teams wrote 10-25 page strategic plans and operational
re-views, and they presented their plans and accomplishments to their
board during multi-hour, highly interactive meetings.  The boards of
directors approved major capital decisions and set compensation for
the team. At the end of each meeting, they evaluated the team and its
members on several Likert scales. These evaluations were a major
component of students' grades.  Team members communicated both
synchronously (scheduled face-to-face meetings, telephone calls,
impromptu discussions in corridors) and asynchronously (email and file
shar-ing). Because team members had different work and class
schedules, teams worked in a distrib-uted manner much of the time."

==============================================================================
From Sue Fussell:
==============================================================================
A few additional notes:

In this year of the Management Game, participants were assigned to one of
two conditions.  In the first condition, they each had individual email
archives.  In the second condition, all email within the team was stored in
a team archive (accessible by anyone regardless of who it was initially
addressed to).  The condition is listed in the Firms table.

The game is set up in nations with four teams in each nation.  In all
cases, teams with the same number had the same starting position at the
onset of the game.  The FIRMID gives the nation and team number for each
team.

As far as groups and threads are concerned, this should be retrievable from
the various tables in the spreadsheet.  The ToIDs lists all the recipients
for a given mesage.  The threading is given in the Parents and References
tables.  So far as I know, we did not analyze this data and so no fancier
queries are available.

